import collections, hashlib, json, math, pathlib, subprocess, urllib.parse
from freeze import HERE, REPO, CONTENT, WORKSPACE, sha, write

def read(name):return json.loads((HERE/name).read_text())
def lines(name):return [json.loads(s) for s in (HERE/name).read_text().splitlines()]
assets=read('direct.json');frozen=read('frozen-manifest.json');before=lines('source-before.jsonl');after=lines('source-after.jsonl')
initial=lines('attempt-1-offscreen/wk.jsonl')
initial_rows=[r for r in initial if r['event']=='result']
final_wk=lines('wk.jsonl');final_wk_rows=[r for r in final_wk if r['event']=='result']
assert final_wk_rows[:len(initial_rows)]==initial_rows and len(initial_rows)==377
# The revived handoff checks recorded payload hashes; it never rehashes source media.
assert before==lines('attempt-1-offscreen/source-after.jsonl')

assert len(assets)==12359 and collections.Counter(a['kind'] for a in assets)=={'portraits':2707,'audio':9652}
assert len(before)==len(after)==len(assets)
assert before==after and all(r['ok'] for r in before)
assert assets==frozen['assets']
for index,(a,r) in enumerate(zip(assets,before)):
 assert r['index']==index and r['path']==a['path'] and r['source_path']==a['source_path']
 assert r['manifest_sha256']==r['source_sha256']==r['payload_sha256']==a['sha256']
 assert r['manifest_size']==r['source_bytes']==r['payload_bytes']==a['size']
assert read('route-provenance.json')['route_equal']
removed=[];media_extensions={'.mp3','.jpg','.jpeg','.png','.wav','.ogg','.webp','.mp4','.m4a','.flac','.aac','.gif','.bmp','.opus','.avif'}
for row in read('nonassets.json'):
 p=HERE/'nonassets'/row['path']
 if p.suffix.lower() in media_extensions:
  if p.exists():
   assert p.stat().st_size==row['size'];p.unlink()
  removed.append(row)
 else:assert p.stat().st_size==row['size']
write('private-media-copy-cleanup.json',{'removedCount':len(removed),'removedBytes':sum(r['size'] for r in removed),'reason':'Initial recursive nonassets snapshot included ported media. Removed only own private copies; immutable frozen path/size/SHA ledger remains. No source payload rehash/decode in revived handoff.','removed':removed})

summary={};failure_union=set();png_jpg=[];magic_counts={}
for runtime in ['chrome','wk']:
 events=lines(runtime+'.jsonl');rows=[r for r in events if r['event']=='result'];lookup={r['index']:r for r in rows}
 assert len(rows)==len(lookup)==len(assets),(runtime,'incomplete or duplicate')
 assert set(lookup)==set(range(len(assets)))
 assert any(r['event']=='done' and not r['stopped'] for r in events)
 assert (read(runtime+'-remaining.json'))==[]
 http=0;passed=collections.Counter();failed=collections.Counter();samples=0;duration=0;silent=[];mimes=collections.Counter();magic=collections.Counter();dimensions=collections.Counter();rates=collections.Counter();channels=collections.Counter();all_failures=[]
 for index,a in enumerate(assets):
  r=lookup[index];assert all(r[k]==a[k] for k in ['path','kind','source_path','source_category'])
  assert r['sourceSHA']==a['sha256'] and r['sha256']==a['sha256'] and r['bytes']==a['size']
  assert r['url'].endswith('/original-content/'+ '/'.join(urllib.parse.quote(p,safe="~!*'()") for p in ('assets/'+a['path']).split('/')))
  assert r['http']['status']==200 and r['http']['ok'] and int(r['http']['contentLength'])==a['size'];http+=1
  mimes[r['http']['mime']]+=1
  h=r['magicHex'];fmt=('png' if h.startswith('89504e470d0a1a0a') else 'jpeg' if h.startswith('ffd8') else 'm4a-container' if '667479704d344120' in h else 'id3' if h.startswith('494433') else 'other');magic[fmt]+=1
  if runtime=='chrome' and fmt=='png' and a['path'].endswith('.jpg'):png_jpg.append(a['path'])
  if r.get('decoderOK'):
   if a['kind']=='portraits':
    d=r['image'];assert d['completeDecode'] and d['complete'] and d['naturalWidth']==d['bitmapWidth']>0 and d['naturalHeight']==d['bitmapHeight']>0;dimensions[str((d['naturalWidth'],d['naturalHeight']))]+=1
   else:
    d=r['audio'];assert d['completePCMDecode'] and d['frames']>0 and d['channels']>0 and d['scannedSamples']==d['frames']*d['channels'] and d['nonfiniteSamples']==0
    assert math.isclose(d['duration'],d['frames']/d['sampleRate'],rel_tol=1e-12) and math.isfinite(d['peak']) and math.isfinite(d['rms'])
    samples+=d['scannedSamples'];duration+=d['duration'];rates[str(d['sampleRate'])]+=1;channels[str(d['channels'])]+=1
    if d['silent']:silent.append({'index':index,'path':a['path']})
  if r['ok']:
   assert r['decoderOK'] and (a['kind']!='audio' or r['metadataOK']);passed[a['kind']]+=1
  else:
   failed[a['kind']]+=1;failure_union.add(a['path']);all_failures.append(r)
 summary[runtime]={'httpVerified':http,'passed':dict(passed),'failed':dict(failed),'scannedPCMSamples':samples,'sumDecodedAudioSeconds':duration,'pcmSampleRates':dict(rates),'channels':dict(channels),'mimeCounts':dict(mimes),'magicCounts':dict(magic),'silentPCM':silent,'firstFailure':all_failures[0] if all_failures else None,'allFailures':[{'index':r['index'],'path':r['path'],'error':r.get('decodeError',r.get('error')),'metadata':r.get('metadata')} for r in all_failures]}
 write(runtime+'-image-dimensions.json',dict(dimensions))
write('png-with-jpg-extension.json',png_jpg)
with (HERE/'container-inspection.log').open('w') as output:
 with_command=['/opt/zerobrew/bin/ffprobe','-v','error','-show_entries','stream=codec_name,profile,codec_tag_string,sample_rate,channels,channel_layout,duration:format=format_name,duration,size','-of','json']
 for path in sorted(failure_union):
  relative='content/original/assets/'+path
  argv=with_command+[relative]
  output.write(json.dumps({'command':argv,'purpose':'container/encoded-stream metadata only; not browser decoding'})+'\n');output.flush()
  result=subprocess.run(argv,cwd=REPO,stdout=output,stderr=subprocess.STDOUT)
  assert result.returncode==0,(argv,result.returncode)
write('audit.json',{'date':subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip(),'assertionsPassed':True,'directTotal':len(assets),'directBytes':sum(a['size'] for a in assets),'sourceBeforeAfterEqual':True,'nonassetsFrozenCount':len(read('nonassets.json')),'pngWithJpgExtension':len(png_jpg),'runtime':summary,'failureUnion':sorted(failure_union),'noStagedFiles':not subprocess.check_output(['git','-C',str(REPO),'diff','--cached','--name-only'],text=True).strip()})
assert not subprocess.check_output(['git','-C',str(REPO),'diff','--cached','--name-only'],text=True).strip()
manifest={}
evidence_names=['chrome.jsonl','wk.jsonl','source-before.jsonl','source-after.jsonl','frozen-manifest.json','direct.json','nonassets.json','audit.json','audit.py','container-inspection.log','private-media-copy-cleanup.json','attempt-1-offscreen/wk.jsonl','attempt-1-offscreen/source-after.jsonl']
for name in evidence_names:
 p=HERE/name;manifest[name]={'size':p.stat().st_size,'sha256':sha(p),'scope':'new evidence-artifact digest only; source payloads not reread'}
write('evidence-sha256.json',manifest)
print(json.dumps({'auditAssertionsPassed':True,'runtime':{k:{'httpVerified':v['httpVerified'],'passed':v['passed'],'failed':v['failed'],'scannedPCMSamples':v['scannedPCMSamples'],'silentPCMCount':len(v['silentPCM'])} for k,v in summary.items()},'pngWithJpgExtension':len(png_jpg)},ensure_ascii=False))
