function originalResourceUrl(base, asset) {
  if (typeof asset !== "string" || !asset || !asset.split("/").every((part) =>
    part && part !== "." && part !== ".." && !/[\\%?#:\u0000-\u001f]/.test(part),
  )) return "";
  return `${base}/${asset.split("/").map(encodeURIComponent).join("/")}`;
}
