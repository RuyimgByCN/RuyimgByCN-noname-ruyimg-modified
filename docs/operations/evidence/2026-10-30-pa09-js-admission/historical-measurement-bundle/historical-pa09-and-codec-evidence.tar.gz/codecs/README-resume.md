本目录保存 2026-10-30 的原始资源解码资格证据；不是产品代码。

原 run 已完成，无待续索引。`chrome-remaining.json`、`wk-remaining.json` 都应为 `[]`。

- `frozen-manifest.json` / `direct.json`：原始 12,359 direct 范围；后来的 aliases 不增加分母。
- `source-before.jsonl`、`source-after.jsonl`、`attempt-1-offscreen/source-after.jsonl`：原 run 已执行的源与服务文件长度/SHA；恢复 handoff 仅比较既有记录，不重新读源媒体做 hash。
- `chrome.jsonl`：12,359 条结果，含原始 5 个 Chrome EncodingError；没有逐项重试 Chrome 失败。
- `wk.jsonl`：初始无窗口 377 个成功结果 + 中断事件 + 可见非激活私有 panel 续跑其余 11,982 个结果；没有导入 Chrome 结果，也没有删除或覆盖初始结果。
- `attempt-1-offscreen/`：首次代码、binary、配置和日志；初次 WK 退出 -15 是手动停止 own 卡住的 helper，不是 decode 通过。
- `commands.json`、`controller*.log`：实际初次/续跑命令和退出；Swift 编译仅原 run 各一次，Cargo 从未编译。
- `harness-sha256.json` 和 `attempt-1-offscreen/harness-sha256.json`：对应原 run 的 harness/binary 身份。
- `audit.py`：恢复时的静态覆盖/证据核对；不发 HTTP、不启动浏览器、不重新编译、不重复源媒体 hash/decode。仅对新证据文件生成 SHA；`ffprobe -show_entries` 仅对 5 个异常识别容器/编码流元数据，绝不充当浏览器 decode。首轮 `file`/`afinfo` 输出及 afinfo 按 .mp3 后缀误识别/报错保存在 `initial-afinfo-*`，未用于确认 codec。

原 `driver.py` 支持中断后的剩余索引续跑：只跳过已落盘 result（包括失败），不会以成功覆盖失败。若需要恢复旧的部分 run，先保存该次 source-after.jsonl、summary、config、harness 身份和 controller 日志，防止覆盖。已经完整的本 run 不需要再执行 driver，也不应删除现有结果来重试。

初版 nonassets 递归包含 ported 媒体副本，恢复核对已删掉仅本目录的 10,807 个媒体副本（902,548,022 字节），保留完整路径/长度/冻结 SHA 账和非媒体快照；未保留 PCM。主树或 canonical source 的媒体未删除。
