import collections, hashlib, json, os, pathlib, re, shutil, subprocess, sys, time
HERE=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/Users/ruyimg/Documents/Claude/sanguosha/noname-next')
WORKSPACE=REPO.parent
CONTENT=REPO/'content/original'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
 return h.hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
def write(name,v): (HERE/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def freeze():
 if (HERE/'frozen-manifest.json').exists(): raise RuntimeError('Freeze already exists; use resume, never overwrite')
 shutil.copyfile(CONTENT/'asset-manifest.json',HERE/'frozen-manifest.json')
 m=json.loads((HERE/'frozen-manifest.json').read_text()); assets=m['assets']
 # Direct paths in this schema preserve either portrait basename or audio source path.
 direct=[a for a in assets if a['source_category']=='core' and (a['path']==a['source_path'] or (a['kind']=='portraits' and a['source_path']=='image/character/'+a['path'].removeprefix('portraits/')))]
 aliases=[a for a in assets if a not in direct]
 source_roots={k:(WORKSPACE/v['root']).resolve() for k,v in m['sources'].items() if v}
 provenance={'date':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'main_head':git(REPO,'rev-parse','HEAD'),'main_status':git(REPO,'status','--short'),'staged':git(REPO,'diff','--cached','--name-only'),'source_roots':{k:{'relative_root':str(p.relative_to(WORKSPACE)),'head':git(p,'rev-parse','HEAD'),'status':git(p,'status','--short')} for k,p in source_roots.items()},'manifest_sha256':sha(HERE/'frozen-manifest.json'),'direct_count':len(direct),'direct_kinds':dict(collections.Counter(a['kind'] for a in direct)),'direct_bytes':dict((k,sum(a['size'] for a in direct if a['kind']==k)) for k in set(a['kind'] for a in direct)),'alias_count':len(aliases),'server_binary_sha256':sha('/tmp/noname-resource-server-329'),'os':subprocess.check_output(['sw_vers'],text=True)}
 assert provenance['server_binary_sha256']=='9ef4b49544bbd35640caf3abf240714af4cd3e0fc56a711c1f5ad502ce0d3489'
 assert not provenance['staged']
 write('provenance.json',provenance);write('direct.json',direct);write('aliases.json',aliases)
 # Preserve nonasset data independently, including full frozen catalog/source/package data.
 nonassets=[]
 for p in sorted(CONTENT.rglob('*')):
  rel=p.relative_to(CONTENT)
  if rel.parts[0]=='assets' or not p.is_file():continue
  dst=HERE/'nonassets'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
  nonassets.append({'path':str(rel),'size':p.stat().st_size,'sha256':sha(dst)})
 write('nonassets.json',nonassets)
 for name in ['apps/game-server/src/main.rs','apps/game-server/src/config.rs','apps/web-client/src/engine/originalResources.ts','crates/engine-api/src/version.rs']:
  dst=HERE/'source-snapshot'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/name,dst)
 old=git(REPO,'show','255bbfbd7f6916ee77bd29799826a225bd10871f:apps/game-server/src/main.rs')
 (HERE/'server329-main.rs').write_text(old+'\n')
 current=(REPO/'apps/game-server/src/main.rs').read_text()
 extract=lambda s:s[s.index('fn build_router('):s.index('\n#[derive(Debug, Default, Deserialize)]',s.index('fn build_router('))]
 a,b=extract(old),extract(current)
 write('route-provenance.json',{'binary_build_head':'255bbfbd7f6916ee77bd29799826a225bd10871f','binary_rule_target':329,'current_rule_target':'330 uncommitted; not binary target','route_equal':a==b,'route_sha256':hashlib.sha256(a.encode()).hexdigest(),'current_route_sha256':hashlib.sha256(b.encode()).hexdigest(),'serve_dir':'ServeDir::new(&cfg.original_content_root); .nest_service("/original-content", original_content)','full_current_main_sha256':sha(REPO/'apps/game-server/src/main.rs')})
 assert a==b
 verify('before')
def verify(stage):
 m=json.loads((HERE/'frozen-manifest.json').read_text()); direct=json.loads((HERE/'direct.json').read_text())
 roots={k:WORKSPACE/v['root'] for k,v in m['sources'].items() if v}
 counts=collections.Counter()
 with open(HERE/f'source-{stage}.jsonl','x') as out:
  for i,a in enumerate(direct):
   src=roots[a['source_category']]/a['source_path']; payload=CONTENT/'assets'/a['path']
   row={'index':i,'path':a['path'],'source_path':a['source_path'],'manifest_size':a['size'],'manifest_sha256':a['sha256']}
   try:
    row.update(source_bytes=src.stat().st_size,source_sha256=sha(src),payload_bytes=payload.stat().st_size,payload_sha256=sha(payload))
    row['ok']=row['source_bytes']==row['payload_bytes']==a['size'] and row['source_sha256']==row['payload_sha256']==a['sha256']
   except Exception as e: row.update(ok=False,error=str(e))
   counts[str(row['ok'])]+=1;out.write(json.dumps(row,ensure_ascii=False)+'\n')
  out.flush();os.fsync(out.fileno())
 write(f'source-{stage}-summary.json',dict(counts))
 print(json.dumps({'stage':stage,'counts':dict(counts)}),flush=True)
if __name__=='__main__': freeze() if sys.argv[1]=='freeze' else verify(sys.argv[1])
