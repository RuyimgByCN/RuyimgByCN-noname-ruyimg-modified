// Standalone qualification only; all bytes are fetched from real Rust ServeDir.
async function runProbe(config, emit) {
  const report = data => emit(JSON.stringify({...data, at: new Date().toISOString()}));
  const context = new OfflineAudioContext(1, 1, 48000);
  report({event:'runtime',userAgent:navigator.userAgent,platform:navigator.platform,origin:location.origin,contextType:'OfflineAudioContext',pcmSampleRate:context.sampleRate,concurrency:2,imageMethods:['HTMLImageElement.decode','createImageBitmap'],audioMethod:'decodeAudioData + scan every PCM sample',metadataMethod:'HTMLAudioElement loadedmetadata (separate; not whole decode)',probeSha256:config.probeSha256});
  let next = 0, stopped = false;
  const deadline = (p, ms, label) => {
    let timer;
    return Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+' timeout '+ms+'ms')),ms);})]).finally(()=>clearTimeout(timer));
  };
  const metadata = (url) => new Promise(resolve => {
    const element = document.createElement('audio'); element.preload='metadata';
    let done = false;
    const finish = value => {if(done)return;done=true;clearTimeout(timer);element.onloadedmetadata=null;element.onerror=null;element.removeAttribute('src');element.load();resolve(value);};
    const timer = setTimeout(()=>finish({ok:false,error:'loadedmetadata timeout 15000ms'}),15000);
    element.onloadedmetadata=()=>finish({ok:Number.isFinite(element.duration)&&element.duration>0,duration:element.duration,readyState:element.readyState});
    element.onerror=()=>finish({ok:false,error:'MediaError '+element.error?.code,message:element.error?.message??''});
    element.src=url;element.load();
  });
  async function one(asset) {
    const started=performance.now(), abort=new AbortController();
    const row={event:'result',index:asset.index,path:asset.path,source_path:asset.source_path,kind:asset.kind,source_category:asset.source_category,expectedBytes:asset.size,sourceSHA:asset.sha256,url:originalResourceUrl(config.base,'assets/'+asset.path),ok:false};
    let objectURL=null,image=null,bitmap=null,buffer=null,pcm=null;
    try {
      const response=await fetch(row.url,{signal:abort.signal,cache:'no-store'});
      row.http={status:response.status,mime:response.headers.get('content-type'),contentLength:response.headers.get('content-length'),contentEncoding:response.headers.get('content-encoding'),acceptRanges:response.headers.get('accept-ranges'),url:response.url};
      buffer=await response.arrayBuffer();row.bytes=buffer.byteLength;
      row.sha256=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',buffer)),x=>x.toString(16).padStart(2,'0')).join('');
      row.http.ok=response.status===200&&row.bytes===asset.size&&row.sha256===asset.sha256&&Number(row.http.contentLength)===asset.size;
      if(!row.http.ok)throw new Error('HTTP/status/length/SHA mismatch');
      row.magicHex=Array.from(new Uint8Array(buffer,0,Math.min(16,buffer.byteLength)),x=>x.toString(16).padStart(2,'0')).join('');
      if(asset.kind==='portraits') {
        const blob=new Blob([buffer],{type:row.http.mime??''});objectURL=URL.createObjectURL(blob);
        image=new Image();image.src=objectURL;
        await image.decode();
        bitmap=await createImageBitmap(blob);
        row.image={naturalWidth:image.naturalWidth,naturalHeight:image.naturalHeight,complete:image.complete,bitmapWidth:bitmap.width,bitmapHeight:bitmap.height,completeDecode:true};
        row.decoderOK=image.complete&&image.naturalWidth>0&&image.naturalHeight>0&&image.naturalWidth===bitmap.width&&image.naturalHeight===bitmap.height;
      } else if(asset.kind==='audio') {
        try {
          pcm=await context.decodeAudioData(buffer);buffer=null;
          let samples=0,nonfinite=0,peak=0,sumSquares=0;
          for(let channel=0;channel<pcm.numberOfChannels;channel++){
            const data=pcm.getChannelData(channel);
            for(let n=0;n<data.length;n++){const v=data[n];if(!Number.isFinite(v))nonfinite++;else {peak=Math.max(peak,Math.abs(v));sumSquares+=v*v;}samples++;}
          }
          row.audio={duration:pcm.duration,channels:pcm.numberOfChannels,sampleRate:pcm.sampleRate,frames:pcm.length,scannedSamples:samples,nonfiniteSamples:nonfinite,peak,rms:Math.sqrt(sumSquares/samples),silent:peak===0,completePCMDecode:true};
          row.decoderOK=pcm.duration>0&&pcm.numberOfChannels>0&&pcm.length>0&&nonfinite===0&&samples===pcm.numberOfChannels*pcm.length;
        }catch(error){row.decoderOK=false;row.decodeError={name:error.name,message:error.message};}
        pcm=null;
        row.metadata=await metadata(row.url);
        row.metadataOK=row.metadata.ok;
      } else throw new Error('Unexpected frozen direct asset kind '+asset.kind);
      row.ok=row.http.ok&&row.decoderOK&&(asset.kind!=='audio'||row.metadataOK);
    } catch(error){row.error={name:error.name,message:error.message};}
    finally {abort.abort();bitmap?.close();if(image)image.removeAttribute('src');if(objectURL)URL.revokeObjectURL(objectURL);image=null;bitmap=null;buffer=null;pcm=null;}
    row.elapsedMs=Math.round((performance.now()-started)*100)/100;return row;
  }
  async function lane(){while(!stopped&&next<config.assets.length){const asset=config.assets[next++];try {const row=await deadline(one(asset),60000,'resource');report(row);}catch(error){stopped=true;report({event:'result',index:asset.index,path:asset.path,kind:asset.kind,sourceSHA:asset.sha256,ok:false,error:{name:error.name,message:error.message},fatalTimeout:true});}}}
  await Promise.all([lane(),lane()]);
  report({event:'done',attempted:next,scheduled:config.assets.length,stopped});
}
