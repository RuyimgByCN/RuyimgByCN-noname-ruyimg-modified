import {readFileSync,writeFileSync,appendFileSync,existsSync,rmSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url));
const config=JSON.parse(readFileSync(join(here,'chrome-config.json'),'utf8'));
const profile=join(here,'chrome-profile');
const output=join(here,'chrome.jsonl');
const log=await import('node:fs').then(fs=>fs.openSync(join(here,'chrome-runtime.log'),'a'));
const chrome=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless=new',`--user-data-dir=${profile}`,'--remote-debugging-port=0','--no-first-run','--no-default-browser-check','--disable-background-networking','about:blank'],{stdio:['ignore',log,log]});
writeFileSync(join(here,'chrome-pid.json'),JSON.stringify({pid:chrome.pid,profile}));
const wait=ms=>new Promise(r=>setTimeout(r,ms));let ws,id=0;const pending=new Map();let results=0;
try{
 for(let i=0;i<200&&!existsSync(join(profile,'DevToolsActivePort'));i++){if(chrome.exitCode!==null)throw new Error('Chrome exited '+chrome.exitCode);await wait(100);}
 const port=readFileSync(join(profile,'DevToolsActivePort'),'utf8').split('\n')[0];
 const pages=await fetch(`http://127.0.0.1:${port}/json/list`).then(r=>r.json());
 ws=new WebSocket(pages.find(p=>p.type==='page').webSocketDebuggerUrl);
 await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
 const send=(method,params={})=>new Promise((resolve,reject)=>{const key=++id;pending.set(key,{resolve,reject});ws.send(JSON.stringify({id:key,method,params}));});
 let doneResolve;const done=new Promise(r=>doneResolve=r);
 ws.onmessage=({data})=>{const msg=JSON.parse(data);if(msg.id){const p=pending.get(msg.id);pending.delete(msg.id);if(p)(msg.error?p.reject(msg.error):p.resolve(msg.result));}else if(msg.method==='Runtime.bindingCalled'&&msg.params.name==='probeReport'){
  const row=JSON.parse(msg.params.payload);appendFileSync(output,JSON.stringify(row)+'\n');if(row.event==='result'&&++results%250===0)console.log(JSON.stringify({runtime:'chrome',completed:results,index:row.index}));if(row.event==='done')doneResolve(row);
 }else if(msg.method==='Runtime.exceptionThrown'){appendFileSync(join(here,'chrome-exceptions.jsonl'),JSON.stringify(msg.params)+'\n');}};
 await send('Runtime.enable');await send('Page.enable');await send('Runtime.addBinding',{name:'probeReport'});
 writeFileSync(join(here,'chrome-version.json'),JSON.stringify(await send('Browser.getVersion'),null,2)+'\n');
 await send('Page.navigate',{url:config.base.replace('/original-content','')+'/health'});
 for(let i=0;i<100;i++){const result=await send('Runtime.evaluate',{expression:'document.readyState',returnByValue:true});if(result.result.value==='complete')break;await wait(50);}
 const script=readFileSync(join(here,'url-helper.js'),'utf8')+'\n'+readFileSync(join(here,'probe.js'),'utf8')+`\nrunProbe(${JSON.stringify(config)},probeReport).catch(error=>probeReport(JSON.stringify({event:'fatal',name:error.name,message:error.message})));`;
 const evaluation=await send('Runtime.evaluate',{expression:script,awaitPromise:false,returnByValue:true});if(evaluation.exceptionDetails)throw new Error(JSON.stringify(evaluation.exceptionDetails));
 const timeout=setTimeout(()=>doneResolve({event:'driverTimeout',ok:false}),75*60*1000);
 const result=await done;clearTimeout(timeout);console.log(JSON.stringify({runtime:'chrome',result}));if(result.event!=='done'||result.stopped)process.exitCode=1;
}finally{
 ws?.close();chrome.kill('SIGTERM');if(chrome.exitCode===null)await Promise.race([new Promise(r=>chrome.once('exit',r)),wait(10000)]);if(chrome.exitCode===null){chrome.kill('SIGKILL');await new Promise(r=>chrome.once('exit',r));}
 rmSync(profile,{recursive:true,force:true});writeFileSync(join(here,'chrome-cleanup.json'),JSON.stringify({pid:chrome.pid,exitCode:chrome.exitCode,signalCode:chrome.signalCode,profileRemoved:!existsSync(profile)}));
}
