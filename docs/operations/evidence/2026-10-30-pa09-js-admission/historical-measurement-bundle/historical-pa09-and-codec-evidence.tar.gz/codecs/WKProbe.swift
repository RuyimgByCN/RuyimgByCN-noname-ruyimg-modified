import Cocoa
import WebKit
import Foundation

final class Probe: NSObject, NSApplicationDelegate, WKNavigationDelegate, WKScriptMessageHandler {
    let root: URL
    let output: FileHandle
    var web: WKWebView!
    var panel: NSPanel!
    var count = 0
    var ended = false
    init(root: URL) throws {
        self.root = root
        let path = root.appendingPathComponent("wk.jsonl").path
        if !FileManager.default.fileExists(atPath:path) { FileManager.default.createFile(atPath:path,contents:Data()) }
        output = try FileHandle(forWritingTo:URL(fileURLWithPath:path))
        try output.seekToEnd()
        super.init()
    }
    func append(_ text: String) {
        try! output.write(contentsOf:Data((text+"\n").utf8))
    }
    func applicationDidFinishLaunching(_ notification: Notification) {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.userContentController.add(self,name:"probeReport")
        web = WKWebView(frame:NSRect(x:0,y:0,width:800,height:600),configuration:configuration)
        web.navigationDelegate = self
        panel = NSPanel(contentRect:NSRect(x:20,y:40,width:420,height:280),styleMask:[.titled,.nonactivatingPanel],backing:.buffered,defer:false)
        panel.title = "Owned resource decoder qualification"
        panel.hidesOnDeactivate = false
        panel.isFloatingPanel = true
        panel.contentView = web
        panel.orderFrontRegardless()
        let configData = try! Data(contentsOf:root.appendingPathComponent("wk-config.json"))
        let config = try! JSONSerialization.jsonObject(with:configData) as! [String:Any]
        let base = config["base"] as! String
        let kit = Bundle(path:"/System/Library/Frameworks/WebKit.framework")
        let version: [String:Any] = ["event":"nativeRuntime", "runtime":"WKWebView", "os":ProcessInfo.processInfo.operatingSystemVersionString, "webKitBundleVersion":kit?.object(forInfoDictionaryKey:"CFBundleVersion") ?? "unknown", "webKitShortVersion":kit?.object(forInfoDictionaryKey:"CFBundleShortVersionString") ?? "unknown", "pid":ProcessInfo.processInfo.processIdentifier, "dataStore":"nonPersistent", "activationPolicy":"accessory", "windowCreated":true, "windowType":"NSPanel nonactivatingPanel orderFrontRegardless; no key/activation/input API called"]
        append(String(decoding:try! JSONSerialization.data(withJSONObject:version,options:[.sortedKeys]),as:UTF8.self))
        web.load(URLRequest(url:URL(string:base.replacingOccurrences(of:"/original-content",with:"")+"/health")!))
        DispatchQueue.main.asyncAfter(deadline:.now()+4500) { self.finish(code:2,reason:"WK driver timeout 75 minutes") }
    }
    func webView(_ webView:WKWebView,didFinish navigation:WKNavigation!) {
        let helper = try! String(contentsOf:root.appendingPathComponent("url-helper.js"),encoding:.utf8)
        let probe = try! String(contentsOf:root.appendingPathComponent("probe.js"),encoding:.utf8)
        let config = try! String(contentsOf:root.appendingPathComponent("wk-config.json"),encoding:.utf8)
        let script = helper+"\n"+probe+"\nrunProbe("+config+", value=>window.webkit.messageHandlers.probeReport.postMessage(value)).catch(error=>window.webkit.messageHandlers.probeReport.postMessage(JSON.stringify({event:'fatal',name:error.name,message:error.message})));void 0;"
        webView.evaluateJavaScript(script) { _, error in
            if let error = error { self.finish(code:3,reason:"evaluateJavaScript: \(error)") }
        }
    }
    func webView(_ webView:WKWebView,didFailProvisionalNavigation navigation:WKNavigation!,withError error:Error) { finish(code:4,reason:"navigation: \(error)") }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { finish(code:5,reason:"WebContent process terminated") }
    func userContentController(_ userContentController:WKUserContentController,didReceive message:WKScriptMessage) {
        guard let text = message.body as? String, let data = text.data(using:.utf8), let row = try? JSONSerialization.jsonObject(with:data) as? [String:Any] else { finish(code:6,reason:"invalid WK message");return }
        append(text)
        if row["event"] as? String == "result" { count += 1;if count % 250 == 0 { print("WK completed \(count) index \(row["index"] ?? "unknown")");fflush(stdout);try! output.synchronize() } }
        if row["event"] as? String == "done" { finish(code:(row["stopped"] as? Bool == true ? 7 : 0),reason:"done") }
        if row["event"] as? String == "fatal" { finish(code:8,reason:"fatal JS: \(text)") }
    }
    func finish(code:Int32,reason:String) {
        if ended { return };ended=true
        append(String(decoding:try! JSONSerialization.data(withJSONObject:["event":"nativeExit","code":code,"reason":reason],options:[.sortedKeys]),as:UTF8.self))
        try! output.synchronize();try! output.close()
        web?.stopLoading();web?.configuration.userContentController.removeScriptMessageHandler(forName:"probeReport")
        panel?.close();panel = nil
        web = nil
        exit(code)
    }
}
let app = NSApplication.shared
app.setActivationPolicy(.accessory)
let delegate = try Probe(root:URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true))
app.delegate = delegate
app.run()
