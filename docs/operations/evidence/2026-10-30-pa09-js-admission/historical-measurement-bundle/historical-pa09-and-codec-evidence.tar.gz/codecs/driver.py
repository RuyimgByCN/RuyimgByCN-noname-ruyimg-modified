import collections, hashlib, json, os, pathlib, re, shutil, signal, socket, subprocess, sys, time, urllib.request
from freeze import HERE, REPO, CONTENT, freeze, verify, sha, write
START=time.monotonic()
commands=json.loads((HERE/'commands.json').read_text()) if (HERE/'commands.json').exists() else []
def command(argv, **kw):
 print(json.dumps({'command':argv,'at':time.strftime('%FT%TZ',time.gmtime())}),flush=True)
 started=time.monotonic();r=subprocess.run(argv,**kw);commands.append({'argv':argv,'exit':r.returncode,'seconds':time.monotonic()-started});write('commands.json',commands)
 if r.returncode: raise RuntimeError('Command failed: '+str(argv))
 return r
def results(runtime):
 p=HERE/(runtime+'.jsonl')
 if not p.exists():return []
 return [r for line in p.read_text().splitlines() if (r:=json.loads(line)).get('event')=='result']
def summary():
 assets=json.loads((HERE/'direct.json').read_text());out={}
 for runtime in ['chrome','wk']:
  rows=results(runtime);indexes={r['index'] for r in rows};kinds={}
  for kind in ['portraits','audio']:
   actual=[r for r in rows if r['kind']==kind];denom=sum(a['kind']==kind for a in assets)
   kinds[kind]={'total':denom,'completed':len(actual),'qualified':sum(bool(r.get('ok')) for r in actual),'failed':sum(not r.get('ok') for r in actual),'decoderPassed':sum(bool(r.get('decoderOK')) for r in actual),'metadataFailed':sum(r.get('metadataOK') is False for r in actual),'silentPCM':sum(r.get('audio',{}).get('silent',False) for r in actual)}
  remaining=[{'index':i,'path':a['path'],'kind':a['kind']} for i,a in enumerate(assets) if i not in indexes]
  write(runtime+'-remaining.json',remaining)
  write(runtime+'-failures.json',[r for r in rows if not r.get('ok')])
  out[runtime]={'results':len(rows),'uniqueIndexes':len(indexes),'remaining':len(remaining),'kinds':kinds,'firstFailure':next((r for r in rows if not r.get('ok')),None)}
 write('summary.json',out);return out
server=None;wk=None;active=None
try:
 write('driver-state.json',{'pid':os.getpid(),'start':time.strftime('%FT%TZ',time.gmtime()),'lock':'/tmp/noname-phase4-heavy-command.lock','cwd':str(HERE)})
 if not (HERE/'frozen-manifest.json').exists():freeze()
 else: print('Resume: preserving frozen inputs and all prior result rows',flush=True)
 ts=(HERE/'source-snapshot/apps/web-client/src/engine/originalResources.ts').read_text()
 helper=ts[ts.index('export function originalResourceUrl('):ts.index('\nexport function originalCharacterAudio')]
 helper=helper.replace('export function originalResourceUrl(base: string, asset: string | null | undefined): string','function originalResourceUrl(base, asset)')
 (HERE/'url-helper.js').write_text(helper)
 assert 'encodeURIComponent' in helper and '\\u0000-\\u001f' in helper
 command(['node','--check',str(HERE/'probe.js')])
 command(['node','--check',str(HERE/'chrome.mjs')])
 modulecache=HERE/'swift-modulecache'
 compiler=['xcrun','swiftc','-module-cache-path',str(modulecache),'-o',str(HERE/'wk-probe'),str(HERE/'WKProbe.swift')]
 if not (HERE/'wk-probe').exists(): command(compiler,stdout=open(HERE/'swift-compile.log','a'),stderr=subprocess.STDOUT)
 command(['xcrun','swiftc','--version'],stdout=open(HERE/'swift-version.txt','a'),stderr=subprocess.STDOUT)
 codefiles=['freeze.py','driver.py','probe.js','url-helper.js','chrome.mjs','WKProbe.swift','wk-probe']
 write('harness-sha256.json',{name:sha(HERE/name) for name in codefiles})
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 base=f'http://127.0.0.1:{port}/original-content'
 env=os.environ.copy();env.update(GAME_SERVER_ADDR=f'127.0.0.1:{port}',NONAME_ORIGINAL_CONTENT_ROOT=str(CONTENT),NONAME_CONTENT_STORE_ROOT=str(HERE/'server-stores/content'),NONAME_NATIVE_STORE_ROOT=str(HERE/'server-stores/native-content'),NONAME_NATIVE_ROOM_STORE=str(HERE/'server-stores/native-rooms'),NONAME_NATIVE_ROOM_NAMESPACE='i02-all-codecs-LXnAxI',NONAME_EXTENSIONS_ROOT=str(HERE/'empty-extensions'),NONAME_NATIVE_PACKAGES_ROOT=str(HERE/'empty-packages'),NONAME_NATIVE_ROOMS='false',RUST_LOG='game_server=info,tower_http=info')
 (HERE/'empty-extensions').mkdir(exist_ok=True);(HERE/'empty-packages').mkdir(exist_ok=True)
 server=subprocess.Popen(['/tmp/noname-resource-server-329'],cwd=HERE,env=env,stdout=open(HERE/'rust-server.log','a'),stderr=subprocess.STDOUT)
 write('server-runtime.json',{'pid':server.pid,'base':base,'binary':'/tmp/noname-resource-server-329','binary_sha256':sha('/tmp/noname-resource-server-329'),'env':{k:v for k,v in env.items() if k.startswith(('NONAME_','GAME_SERVER_'))}})
 for _ in range(100):
  try:
   if urllib.request.urlopen(base.replace('/original-content','')+'/health',timeout=1).read()==b'ok':break
  except Exception:
   if server.poll() is not None:raise RuntimeError('Rust server exited '+str(server.returncode))
   time.sleep(.1)
 else:raise RuntimeError('Rust health timeout')
 assets=json.loads((HERE/'direct.json').read_text())
 # Keep raw HTTP manifest to distinguish live manifest additions from immutable frozen scope.
 with urllib.request.urlopen(base+'/asset-manifest.json',timeout=10) as response:
  (HERE/'http-live-manifest.json').write_bytes(response.read());write('http-manifest-headers.json',dict(response.headers))
 for runtime,argv in [('chrome',['node',str(HERE/'chrome.mjs')]),('wk',[str(HERE/'wk-probe'),str(HERE)])]:
  completed={r['index'] for r in results(runtime)}
  pending=[dict(a,index=i) for i,a in enumerate(assets) if i not in completed]
  write(runtime+'-config.json',{'base':base,'assets':pending,'probeSha256':sha(HERE/'probe.js')})
  if not pending:continue
  print(json.dumps({'starting':runtime,'pending':len(pending),'minutes':(time.monotonic()-START)/60}),flush=True)
  active=subprocess.Popen(argv,cwd=HERE,stdout=open(HERE/(runtime+'-driver.log'),'a'),stderr=subprocess.STDOUT)
  write(runtime+'-driver-pid.json',{'pid':active.pid})
  last=0
  while active.poll() is None:
   elapsed=time.monotonic()-START
   if elapsed-last>=60:
    last=elapsed;current=summary();print(json.dumps({'checkpointMinutes':elapsed/60,'summary':{r:{k:v for k,v in data.items() if k!='firstFailure'} for r,data in current.items()}}),flush=True)
    if elapsed>=3600 and not (HERE/'checkpoint-60min.json').exists():write('checkpoint-60min.json',current)
   if elapsed>5100:
    active.terminate();raise RuntimeError('85 minute deadline: preserve partial results')
   time.sleep(1)
  commands.append({'argv':argv,'exit':active.returncode});write('commands.json',commands)
  print(json.dumps({'finished':runtime,'exit':active.returncode}),flush=True)
  active=None
 verify('after')
 write('final-summary.json',summary())
except Exception as e:
 write('driver-error.json',{'type':type(e).__name__,'message':str(e),'elapsedSeconds':time.monotonic()-START});print('DRIVER ERROR '+str(e),flush=True)
 if (HERE/'direct.json').exists():summary()
 sys.exit(1)
finally:
 cleanup={}
 for label,child in [('active',active),('server',server)]:
  if child:
   if child.poll() is None:
    child.terminate()
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:child.kill();child.wait(timeout=10)
   cleanup[label]={'pid':child.pid,'exit':child.returncode,'waited':True}
 # Chrome's normal finally owns child shutdown; fallback only for our recorded instance.
 p=HERE/'chrome-pid.json'
 if p.exists():
  pid=json.loads(p.read_text())['pid']
  try:os.kill(pid,0)
  except ProcessLookupError:cleanup['chromeAlive']=False
  else:
   os.kill(pid,signal.SIGTERM);cleanup['chromeTerminationFallback']=pid
 for name in ['chrome-profile','swift-modulecache','server-stores']:
  p=HERE/name
  if p.exists():shutil.rmtree(p)
  cleanup[name+'Removed']=not p.exists()
 cleanup['mainStagedFiles']=subprocess.check_output(['git','-C',str(REPO),'diff','--cached','--name-only'],text=True).splitlines()
 cleanup['elapsedSeconds']=time.monotonic()-START
 write('cleanup.json',cleanup)
 print(json.dumps({'cleanup':cleanup}),flush=True)
