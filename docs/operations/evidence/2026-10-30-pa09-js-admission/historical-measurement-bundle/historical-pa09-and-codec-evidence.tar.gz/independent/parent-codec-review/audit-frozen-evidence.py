from pathlib import Path
import collections
import hashlib
import json
import math

ROOT = Path('/tmp/noname-i02-all-codecs.LXnAxI')
OUT = Path('/tmp/parent-codec-review')
OUT.mkdir(exist_ok=True)

def load(path):
    return json.loads(path.read_text())

def lines(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assets = load(ROOT / 'direct.json')
manifest = load(ROOT / 'frozen-manifest.json')
assert len(assets) == 12359 and manifest['assets'] == assets
records = [lines(ROOT / name) for name in ['source-before.jsonl', 'source-after.jsonl', 'attempt-1-offscreen/source-after.jsonl']]
assert records[0] == records[1] == records[2]
assert [row['index'] for row in records[0]] == list(range(12359))
for row, asset in zip(records[0], assets):
    assert row['path'] == asset['path'] and row['source_path'] == asset['source_path']
    assert row['manifest_size'] == row['source_bytes'] == row['payload_bytes'] == asset['size']
    assert row['manifest_sha256'] == row['source_sha256'] == row['payload_sha256'] == asset['sha256']
    assert row['ok'] is True
report = {'scope': 'Pure parsing of frozen records and hashing non-media evidence only; no canonical-media reads/decoders/browser/timing-followup', 'direct_count': len(assets), 'direct_bytes': sum(a['size'] for a in assets), 'kind_counts': dict(collections.Counter(a['kind'] for a in assets)), 'three_source_records_equal': True, 'runtime': {}}
raw_wk = {}
for runtime in ['chrome', 'wk']:
    raw = (ROOT / (runtime + '.jsonl')).read_text().splitlines()
    events = [json.loads(line) for line in raw if line.strip()]
    rows = [row for row in events if row.get('event') == 'result']
    assert len(rows) == 12359
    index = {row['index']: row for row in rows}
    assert len(index) == 12359 and sorted(index) == list(range(12359))
    passed = collections.Counter()
    failed = []
    samples = 0
    for number, row in index.items():
        asset = assets[number]
        for key in ['path', 'kind', 'source_category', 'source_path']:
            assert row[key] == asset[key]
        assert row['expectedBytes'] == row['bytes'] == int(row['http']['contentLength']) == asset['size']
        assert row['sourceSHA'] == row['sha256'] == asset['sha256']
        assert row['http']['status'] == 200 and row['http']['ok'] is True
        if row['kind'] == 'portraits':
            image = row['image']
            assert image['complete'] and image['completeDecode'] and row['decoderOK'] and row['ok']
            assert image['naturalWidth'] == image['bitmapWidth'] > 0
            assert image['naturalHeight'] == image['bitmapHeight'] > 0
        else:
            assert row['metadataOK'] and row['metadata']['ok']
            if row['ok']:
                audio = row['audio']
                assert row['decoderOK'] and audio['completePCMDecode']
                assert audio['frames'] > 0 and audio['channels'] > 0 and audio['sampleRate'] == 48000
                assert audio['scannedSamples'] == audio['frames'] * audio['channels']
                assert audio['nonfiniteSamples'] == 0 and audio['silent'] is False
                assert math.isfinite(audio['peak']) and math.isfinite(audio['rms']) and audio['peak'] > 0 and audio['rms'] > 0
                samples += audio['scannedSamples']
        if row['ok']:
            passed[row['kind']] += 1
        else:
            assert not row['decoderOK'] and row['decodeError']['name'] == 'EncodingError'
            failed.append({'index': number, 'path': row['path'], 'error': row['decodeError']})
    report['runtime'][runtime] = {'events': len(events), 'unique_results': len(index), 'passed': dict(passed), 'failures': sorted(failed, key=lambda x: x['index']), 'scanned_pcm_samples': samples, 'jsonl_sha256': sha(ROOT / (runtime + '.jsonl'))}
    if runtime == 'wk':
        raw_wk = {json.loads(line)['index']: line for line in raw if json.loads(line).get('event') == 'result'}
assert report['runtime']['chrome']['passed'] == {'portraits': 2707, 'audio': 9647}
assert len(report['runtime']['chrome']['failures']) == 5
assert report['runtime']['wk']['passed'] == {'portraits': 2707, 'audio': 9652}
assert not report['runtime']['wk']['failures']
old_lines = (ROOT / 'attempt-1-offscreen/wk.jsonl').read_text().splitlines()
old_results = [line for line in old_lines if json.loads(line).get('event') == 'result']
assert len(old_results) == 377
assert all(raw_wk[json.loads(line)['index']] == line for line in old_results)
report['original_wk377_raw_lines_unchanged'] = True
report['digests'] = {}
text_extensions = {'.json', '.jsonl', '.py', '.js', '.mjs', '.cjs', '.swift', '.log', '.txt', '.stderr', '.stdout', '.sha256', '.html', '.md'}
for relative, base in [('evidence-sha256.json', ROOT), ('harness-sha256.json', ROOT), ('five-followup/final-evidence-sha256.json', ROOT / 'five-followup')]:
    checked, skipped, mismatches = [], [], []
    for name, item in load(ROOT / relative).items():
        path = base / name
        if path.suffix not in text_extensions:
            skipped.append(name)
            continue
        expected = item['sha256'] if isinstance(item, dict) else item
        actual = sha(path)
        if actual != expected or isinstance(item, dict) and 'size' in item and item['size'] != path.stat().st_size:
            mismatches.append({'name': name, 'expected': expected, 'actual': actual})
        checked.append(name)
    report['digests'][relative] = {'checked_count': len(checked), 'skipped_binary_media': skipped, 'mismatches': mismatches}
    assert not mismatches, mismatches
five = ROOT / 'five-followup'
report['five_followup'] = {}
for name, count in [('chrome-five.jsonl', 10), ('candidate-diagnostics/chrome-five.jsonl', 10), ('plain-element-baseline/chrome-five.jsonl', 6)]:
    rows = [row for row in lines(five / name) if row.get('event') == 'result']
    assert len(rows) == count and len({row['path'] for row in rows}) == count
    groups = {}
    for role in sorted({row['role'] for row in rows}):
        group = [row for row in rows if row['role'] == role]
        decode_pass = sum(bool(row.get('decode', {}).get('ok')) for row in group)
        play_pass = sum(bool(row['play'].get('ok')) for row in group)
        for row in group:
            if row['play']['ok']:
                assert row['play']['ended'] and row['play']['terminalEvent'] == 'ended'
                if 'playedPCM' in row:
                    pcm = row['playedPCM']
                    assert pcm['samples'] > 0 and pcm['nonfinite'] == 0 and pcm['nonzero'] > 0
            else:
                assert not row['play']['ended'] and row['play']['currentTime'] == 0
                assert row['play']['error']['code'] == 3
            if 'http' in row:
                assert row['http']['ok'] and row['http']['status'] == 200
                assert row['http']['sha256'] == row['expectedSHA']
                assert row['http']['bytes'] == int(row['http']['contentLength']) == row['expectedBytes']
        groups[role] = {'count': len(group), 'decode_pass': decode_pass, 'play_pass': play_pass, 'mime_values': sorted({row.get('http', {}).get('mime', 'not-recorded') for row in group})}
    report['five_followup'][name] = groups
packets = load(five / 'candidate-diagnostics/packet-comparisons.json')
assert len(packets) == 10
for row in packets:
    assert row['matchesAudioSpecificConfig'] and row['firstOriginalPacketHex'] == '1190'
    assert row['retainedCompressedPacketSHAsExact']
    assert row['originalDecodedFrameCount'] == row['candidateDecodedFrameCount']
    assert row['removedPacketDecodedFrames'] == 0
    if row['mode'] == 'plain':
        assert row['removedPacketCount'] == row['removedPacketBytes'] == 0
        assert row['originalPacketCount'] == row['candidatePacketCount']
    else:
        assert row['mode'] == 'drop-first-config'
        assert row['removedPacketCount'] == 1 and row['removedPacketBytes'] == 2
        assert row['originalPacketCount'] == row['candidatePacketCount'] + 1
        assert not row['timingChanges']
report['packet_comparisons'] = {'rows': 10, 'all_assertions_passed': True, 'drop_first_removed_packet_bytes_each': 2, 'lost_decoded_frames': 0, 'remaining_timing_2112frames': 'Not audited here; timing-followup intentionally excluded'}
report['all_assertions_passed'] = True
(OUT / 'independent-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'all_assertions_passed': True, 'results': str(OUT / 'independent-results.json'), 'runtime': report['runtime']}, indent=2))
