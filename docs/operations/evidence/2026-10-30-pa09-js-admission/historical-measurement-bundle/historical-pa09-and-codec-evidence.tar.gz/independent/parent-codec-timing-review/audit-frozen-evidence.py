from pathlib import Path
import hashlib
import json
import math
import re

ROOT = Path('/tmp/noname-i02-all-codecs.LXnAxI/timing-followup')
OUT = Path('/tmp/parent-codec-timing-review')
OUT.mkdir(exist_ok=True)

def load(name):
    return json.loads((ROOT / name).read_text())

def results(name):
    return [row for line in (ROOT / name).read_text().splitlines() if line.strip() for row in [json.loads(line)] if row.get('event') == 'result']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def statistics(value):
    assert value['frames'] > 0 and value['sampleRate'] == 48000 and value['channels'] == 2
    channels = value['channelStatistics']
    assert len(channels) == 2 and {row['channel'] for row in channels} == {0, 1}
    for channel in channels:
        assert channel['nonfinite'] == 0 and channel['peak'] > 0 and channel['rms'] > 0
        assert math.isfinite(channel['peak']) and math.isfinite(channel['rms'])
        assert re.fullmatch('[a-f0-9]{64}', channel['sha256'])
        assert all(math.isfinite(item) and item >= 0 for item in channel['energy32'])
    return [row['sha256'] for row in channels]

def http(row):
    assert row['status'] == 200 and row['bytes'] == int(row['contentLength'])
    assert re.fullmatch('[a-f0-9]{64}', row['sha256'])

def playback(row):
    assert row['ok'] and row['terminal'] == 'ended' and row['playPromise'] == 'resolved'
    assert row['final']['ended'] and row['final']['error'] is None
    assert row['final']['currentTime'] > 0 and row['final']['currentTime'] == row['final']['duration']
    assert row['progress'] and any(item['currentTime'] > 0 for item in row['progress'])

files = ['alignment-run/wk.jsonl', 'alignment-run/chrome-stats/chrome-five.jsonl', 'chrome-stats/chrome-five.jsonl', 'alignment-run/no-elst-metadata.json', 'cross-decoder-statistics.json', 'minimal-contract-design-fixture.json']
manifest = load('evidence-sha256.json')
report = {'scope': 'Frozen timing six data files + digest manifest + five new candidate bytes only; no original media/decoder/future outputs', 'digests': [], 'WK': [], 'Chrome': [], 'candidates': [], 'cross_decoder': []}
for name in files:
    path = ROOT / name
    item = manifest[name]
    actual = sha(path)
    assert actual == item['sha256'] and path.stat().st_size == item['size'], name
    report['digests'].append({'path': name, 'sha256': actual, 'equal': True})
wk = results(files[0])
assert len(wk) == 10
assert len({(row['name'], row['variant']) for row in wk}) == 10
for row in wk:
    original, candidate, comparison = row['original'], row['candidate'], row['comparison']
    http(original['http']); http(candidate['http'])
    a, b = statistics(original['statistics']), statistics(candidate['statistics'])
    assert len(comparison['channels']) == 2
    is_new = row['variant'] == 'no-elst'
    assert is_new or row['variant'] == 'filtered-with-elst'
    original_frames = original['statistics']['frames']
    candidate_frames = candidate['statistics']['frames']
    assert candidate_frames - original_frames == (0 if is_new else 2112)
    for index, channel in enumerate(comparison['channels']):
        assert channel['overlapFrames'] == original_frames
        assert channel['lagSamples'] == (0 if is_new else 2112)
        assert channel['maxAbsDifference'] == channel['rmsDifference'] == 0
        assert channel['normalizedPCMCorrelation'] == 1
        assert channel['originalOverlapSHA'] == channel['candidateOverlapSHA'] == a[index]
        assert channel['candidateLeadingExtra']['frames'] == (0 if is_new else 2112)
        assert channel['candidateTrailingExtra']['frames'] == 0
        if is_new: assert a[index] == b[index]
    if row['play'] is not None:
        playback(row['play'])
    else:
        assert not is_new, 'no-elst candidates require actual HTML playback'
    report['WK'].append({'name': row['name'], 'variant': row['variant'], 'original_frames': original_frames, 'candidate_frames': candidate_frames, 'full_original_overlap_equal': True, 'full_candidate_bit_equal': is_new, 'lag': 0 if is_new else 2112, 'play_final_time': row['play']['final']['currentTime'] if row['play'] is not None else None})
old_chrome, new_chrome = results(files[2]), results(files[1])
assert len(old_chrome) == len(new_chrome) == 5
for old, new in zip(old_chrome, new_chrome):
    http(old['http']); http(new['http'])
    old_hashes, new_hashes = statistics(old['statistics']), statistics(new['statistics'])
    assert old_hashes == new_hashes and old['statistics']['frames'] == new['statistics']['frames']
    playback(new['play'])
    report['Chrome'].append({'path': new['path'], 'frames': new['statistics']['frames'], 'old_new_full_channel_hashes_equal': True, 'actual_html_ended': True, 'final_time': new['play']['final']['currentTime']})
metadata = load(files[3])
assert len(metadata) == 5
for index, item in enumerate(metadata, 1):
    assert item['name'] == f'tsumugi_mugyu{index}'
    assert item['packetsUnchangedIncludingTiming'] and item['elstPresent'] is False
    packets = item['packetRecords']
    assert len(packets) == item['packetCount'] and packets
    for number, packet in enumerate(packets):
        assert packet['pts'] == packet['dts'] == number * 1024 and packet['duration'] == 1024
        assert packet['size'] > 2 and re.fullmatch('[a-f0-9]{64}', packet['sha256'])
    path = ROOT / 'alignment-run' / f'tsumugi_mugyu{index}-no-elst.m4a'
    assert path.stat().st_size == item['bytes'] and sha(path) == item['candidateSHA']
    assert new_chrome[index - 1]['http']['bytes'] == item['bytes']
    assert new_chrome[index - 1]['http']['sha256'] == item['candidateSHA']
    no_elst = [row for row in wk if row['name'] == item['name'] + '-no-elst'][0]
    assert no_elst['candidate']['http']['sha256'] == item['candidateSHA']
    report['candidates'].append({'name': item['name'], 'bytes': item['bytes'], 'sha256': item['candidateSHA'], 'packet_count': item['packetCount'], 'metadata_http_file_binding_equal': True})
assert sum(row['bytes'] for row in report['candidates']) == 263579
cross = load(files[4])
assert len(cross) == 5
for row in cross:
    assert row['ChromeFrames'] - row['WKFrames'] == 2112
    assert len(row['channels']) == 2
    for channel in row['channels']:
        assert channel['best']['lagSamples'] == 2112
        assert abs(channel['best']['energyEnvelopePearson'] - 1) < 1e-10
        assert channel['alignedEnergyEnvelopeMaxAbsDifference'] <= 5.88e-8
        assert channel['crossDecoderFullPCMBitEqualityClaimed'] is False
    report['cross_decoder'].append({'name': row['name'], 'lag': 2112, 'energy_comparison_only': True, 'bit_equal_claimed': False})
fixture = load(files[5])
assert fixture['designOnly'] and fixture['runtimeSchemaVersion'] == 2 and fixture['rowFieldSetUnchanged']
assert (fixture['originalDirectRowsRemain'], fixture['existingAliasesRemain'], fixture['affectedExistingAliases'], fixture['additionalDerivedBackingRows'], fixture['proposedTotalRows']) == (12359, 23393, 10, 5, 35757)
assert len(fixture['originProvenanceRows']) == 5 and all(row['rejected'] for row in fixture['staticBindingFixtureTests'])
report['design_fixture'] = {'schema': 2, 'original_rows': 12359, 'aliases': 23393, 'affected': 10, 'additional_backing': 5, 'proposed_total': 35757, 'binding_negative_cases': fixture['staticBindingFixtureTests'], 'implementation_proven': False}
correction = json.loads(Path('/tmp/parent-codec-review/mime-correction.json').read_text())
original = Path(correction['original_report']).read_bytes()
adopted = Path(correction['adopted_report']).read_bytes()
assert original.count(b'MIME audio/mp4') == 1
assert adopted == original.replace(b'MIME audio/mp4', b'MIME audio/m4a')
assert hashlib.sha256(original).hexdigest() == correction['original_sha256']
assert hashlib.sha256(adopted).hexdigest() == correction['adopted_sha256']
report['mime_correction'] = {'exactly_one_replacement': True, 'other_bytes_unchanged': True, 'original_preserved': True}
report['all_assertions_passed'] = True
(OUT / 'independent-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'all_assertions_passed': True, 'WK_results': len(wk), 'Chrome_results': len(new_chrome), 'candidate_bytes': 263579, 'path': str(OUT / 'independent-results.json')}))
