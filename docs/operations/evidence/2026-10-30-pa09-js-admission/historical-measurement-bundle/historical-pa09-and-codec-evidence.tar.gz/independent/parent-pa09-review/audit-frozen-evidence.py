from pathlib import Path
import collections
import hashlib
import json
import math

ROOT = Path('/var/folders/b5/2mh_j5tj7m71xhcjsk2z1t4c0000gn/T/noname-pa09-controlled-input-m30foifd/evidence')
OUT = Path('/tmp/parent-pa09-review')
OUT.mkdir(exist_ok=True)

def load(path):
    return json.loads(path.read_text())

def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def quantiles(values):
    ordered = sorted(values)
    assert ordered
    return {'count': len(values), 'p50': ordered[math.ceil(len(ordered) * .50) - 1], 'p95': ordered[math.ceil(len(ordered) * .95) - 1], 'max': ordered[-1], 'values': ordered}

def without_values(value):
    if isinstance(value, dict):
        return {key: without_values(item) for key, item in value.items() if key != 'values'}
    if isinstance(value, list):
        return [without_values(item) for item in value]
    return value

summary = load(ROOT / 'controlled-input-transport-summary.json')
report = {'scope': 'Independent read-only parsing of recorded samples and bounded identity hashes; no build/GUI/benchmark/20k scan/main writes', 'summary_schema': list(summary), 'runs': [], 'comparisons': [], 'identities': [], 'issues': []}
run_steps = []
for declared in summary['runs']:
    name = declared['run']
    root = ROOT / 'runs-controlled' / name
    samples = rows(root / 'samples.ndjson')
    controllers = rows(root / 'controller.ndjson')
    posts = [row for row in controllers if row.get('posted') is True]
    listeners = [row for row in rows(root / 'listener.ndjson') if 'sampleID' in row]
    clicks = rows(root / 'click-requests.ndjson')
    http = rows(root / 'http.ndjson')
    done = load(root / 'done.json')
    traces = [row for row in done['trace'] if row['request'].get('type') == 'autoStep']
    inputs = done['inputEvents']
    ids = {row['sampleID'] for row in samples}
    assert len(samples) == len(ids) == len(traces) == len(clicks) == len(inputs) == 280
    for group in [traces, clicks, inputs]:
        assert {row['sampleID'] for row in group} == ids
    assert len(posts) == len(listeners) == 560
    for group in [posts, listeners]:
        assert collections.Counter(row['sampleID'] for row in group) == {key: 2 for key in ids}
        for key in ids:
            assert {row['type'] for row in group if row['sampleID'] == key} == {1, 2}
    controllers_by_id = {key: [row for row in posts if row['sampleID'] == key] for key in ids}
    clicks_by_id = {row['sampleID']: row for row in clicks}
    for row in listeners:
        key = row['sampleID']
        assert row['source_pid'] == controllers_by_id[key][0]['controller_pid']
        assert row['x'] == clicks_by_id[key]['x'] and row['y'] == clicks_by_id[key]['y']
    assert all(row['trusted'] is True for row in inputs)
    assert all(row['event']['trusted'] is True for row in samples)
    assert all(row['sampleID'] == row['event']['sampleID'] == row['request']['sampleID'] for row in samples)
    trace_by_id = {row['sampleID']: row for row in traces}
    assert all(row['request'] == trace_by_id[row['sampleID']] for row in samples)
    http_samples = [row['body'] for row in http if row['path'] == '/sample']
    assert len(http_samples) == 280
    assert {row['sampleID']: row for row in http_samples} == {row['sampleID']: row for row in samples}
    interactions = [row for row in done['interactions'] if row.get('type') == 'autoStep']
    assert len(interactions) == 280
    measured = {'page_i2p_approx_ms': quantiles([row['perf']['input_to_paint_ms'] for row in samples]), 'invoke_or_worker_roundtrip_ms': quantiles([row['request']['received'] - row['request']['sent'] for row in samples])}
    for key, value in measured.items():
        assert value == declared[key], (name, key, without_values(value), without_values(declared[key]))
    transfer = None
    calibration = None
    worker_clocks = [row for row in done['clocks'] if row.get('source') == 'actual-product-worker']
    if worker_clocks:
        best = min(worker_clocks, key=lambda row: (row['mainReceived'] - row['start']) - (row['sent'] - row['received']))
        main_origin = inputs[0]['origin']
        lower = best['origin'] + best['sent'] - main_origin - best['mainReceived']
        upper = best['origin'] + best['received'] - main_origin - best['start']
        center = (lower + upper) / 2
        values = [main_origin + row['request']['received'] - row['request']['workerTimings']['post_epoch_ms'] + center for row in samples]
        transfer = quantiles(values)
        assert transfer == declared['calibrated_worker_transfer_ms'], (name, without_values(transfer), without_values(declared['calibrated_worker_transfer_ms']))
        calibration = {'pairs': len(worker_clocks), 'best_pair': best, 'raw_worker_minus_main_offset': [lower, upper], 'center': center, 'comparison': 'center values independently recomputed; quantization uncertainty remains as declared, not zero latency error'}
    run_steps.append([(row['request'], row['response']) for row in traces])
    report['runs'].append({'run': name, 'summary_without_values': without_values(declared), 'raw_schema': {'sample': list(samples[0]), 'done': list(done), 'sample_request': list(samples[0]['request'])}, 'counts': {'samples': len(samples), 'unique_ids': len(ids), 'posts': len(posts), 'listeners': len(listeners), 'inputs': len(inputs), 'click_requests': len(clicks), 'http_samples': len(http_samples), 'all_trace_requests': len(done['trace']), 'auto_step_trace': len(traces), 'all_interactions': len(done['interactions']), 'auto_step_interactions': len(interactions)}, 'missing_or_extra_sample_ids': [], 'measured': {key: without_values(value) for key, value in measured.items()}, 'worker_transfer': without_values(transfer), 'worker_calibration': calibration, 'step_kinds': dict(collections.Counter(row['response']['data']['result']['kind'] for row in traces))})
for index in [1, 2]:
    assert run_steps[0] == run_steps[index]
    report['comparisons'].append({'baseline': '01-wasm', 'other': summary['runs'][index]['run'], 'complete_request_response_pairs_equal': len(run_steps[index]), 'excluded_request_response_fields': []})
for name in ['app-product.json', 'app-vm-product.json']:
    item = load(ROOT / name)
    path = Path(item['binary'])
    actual = digest(path)
    assert actual == item['packaged_binary_sha256']
    report['identities'].append({'kind': 'packaged_app_binary', 'path': str(path), 'sha256': actual, 'equal': True})
wasm = ROOT / 'native-pkg/engine_native_wasm_bg.wasm'
assert digest(wasm) == '2292d7ab1c04b05724e49eb750962bb78af119dac80011524b18574742ed189b'
report['identities'].append({'kind': 'native_wasm', 'sha256': digest(wasm), 'equal': True})
for name, base in [('product-source-copy-proof.json', ROOT / 'product-web'), ('fixture-source-copy-proof.json', ROOT / 'product-web/scripts/fixtures')]:
    proof = load(ROOT / name)
    verified = []
    for relative, expected in proof['files'].items():
        path = base / relative
        actual = digest(path)
        assert actual == expected, (name, relative)
        verified.append({'path': relative, 'sha256': actual})
    report['identities'].append({'kind': name, 'count': len(verified), 'files': verified, 'equal': True})
processes = rows(ROOT / 'logs/sampling-build-processes.ndjson')
report['concurrent_build_processes'] = {'snapshots': len(processes), 'nonempty': [row for row in processes if row['heavy_processes']]}
assert len(processes) == 315
lifecycle = load(ROOT / 'runs-lifecycle/01-acceptance/acceptance.json')
trace = lifecycle['trace']
counts = collections.Counter(row['request']['type'] for row in trace)
restores = [row for row in trace if row['request']['type'] == 'restore']
assert counts['save'] == 11 and counts['restore'] == 6
report['lifecycle'] = {'passed': lifecycle['passed'], 'trace_count': len(trace), 'request_counts': dict(counts), 'restore_ok_failed': dict(collections.Counter(str(row['response']['ok']) for row in restores)), 'queue_probe': lifecycle['queueProbe'], 'semantic_archive_schema': [list(row) for row in load(ROOT / 'semantic-archive-evidence.json')], 'archive_records': len(load(ROOT / 'semantic-archive-evidence.json')[-1]['archives'])}
planner_all = rows(ROOT / 'logs/planner-measure.ndjson')
planner = [row for row in planner_all if 'kind' in row]
assert len(planner) == 444
report['planner'] = {'records': len(planner), 'nonmeasurement_rows': len(planner_all) - len(planner), 'kind_counts': dict(collections.Counter(row['kind'] for row in planner)), 'summary_schema': [list(row) for row in load(ROOT / 'planner-summary.json')], 'summary_rows': len(load(ROOT / 'planner-summary.json'))}
report['all_assertions_passed'] = True
(OUT / 'independent-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'all_assertions_passed': True, 'runs': [row['counts'] for row in report['runs']], 'comparisons': report['comparisons'], 'identities': [(row['kind'], row.get('count')) for row in report['identities']], 'planner_count': len(planner), 'results': str(OUT / 'independent-results.json')}, indent=2))
