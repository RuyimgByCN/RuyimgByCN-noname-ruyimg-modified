use engine_native::content::extension::{ExtensionDef, ExtensionPack, InitHook};
use engine_native::event::DamageNature;
use engine_native::{Engine, Phase};
fn pack(body: &str) -> ExtensionPack {
    let source =
        format!("skill c9_target(99109001) {{ trigger damage owner_is_target {{ {body} }} }}");
    let p = content_compiler::compile_source_named("c9-damage", &source).unwrap();
    ExtensionPack {
        def: ExtensionDef {
            name: "c9-damage",
            version: 1,
            description: "real VM damage window",
        },
        generals: vec![],
        cards: vec![],
        host_skills: vec![],
        vm_skills: content_native_loader::bridge_vm_skill_decls(&p)
            .unwrap()
            .decls,
        init_hook: InitHook::None,
        enabled: true,
    }
}
fn engine(p: &ExtensionPack) -> Engine {
    let mut e = Engine::new_with_extensions(11901, 3, &[p]).unwrap();
    e.debug_set_turn(0, Phase::Play, 1);
    e.debug_grant(1, "c9_target");
    e
}
#[test]
fn c9_cancelled_root_does_not_dispatch_target_damage() {
    let p = pack("effect draw_cards(self,1);");
    let mut e = engine(&p);
    e.state_core_mut().player_mut(1).jidong_active = true;
    let hand = e.state_core().player(1).hand.len();
    e.debug_deal_damage(Some(0), 1, 1, DamageNature::Normal);
    assert_eq!(
        e.state_core().player(1).hand.len(),
        hand,
        "cancelled damage has no target damage window"
    );
}
#[test]
fn c9_target_damage_runs_before_dying_subtree() {
    let p = pack("effect recover_hp(self,1);");
    let mut e = engine(&p);
    e.debug_set_hp(1, 1);
    e.debug_deal_damage(Some(0), 1, 1, DamageNature::Normal);
    assert_eq!(
        e.debug_hp(1),
        1,
        "target damage skill recovers before dying collection"
    );
    assert!(e.open_choice().is_none(), "no premature rescue choice");
}
#[test]
fn c9_chain_child_does_not_overtake_parent_dying() {
    let mut e = Engine::new(11902, 3);
    e.debug_set_turn(0, Phase::Play, 1);
    e.debug_set_hp(1, 1);
    e.debug_move_named_card_to_hand(0, "tao");
    e.state_core_mut().player_mut(1).linked = true;
    e.state_core_mut().player_mut(2).linked = true;
    e.debug_deal_damage(Some(0), 1, 1, DamageNature::Fire);
    assert!(e.open_choice().is_some(), "parent rescue is pending");
    assert_eq!(
        e.debug_hp(2),
        4,
        "chain child waits for complete parent dying subtree"
    );
}
fn optional_pack() -> ExtensionPack {
    let p=content_compiler::compile_source_named("c9-optional","skill c9_pause(99109002) { trigger damage owner_is_target optional { effect draw_cards(self,1); } }").unwrap();
    ExtensionPack {
        def: ExtensionDef {
            name: "c9-optional",
            version: 1,
            description: "real target optional pause",
        },
        generals: vec![],
        cards: vec![],
        host_skills: vec![],
        vm_skills: content_native_loader::bridge_vm_skill_decls(&p)
            .unwrap()
            .decls,
        init_hook: InitHook::None,
        enabled: true,
    }
}
#[test]
fn c9_full_armor_retains_source_quantity_positive_receipt_and_zero_hp_loss() {
    let p = optional_pack();
    let mut e = Engine::new_with_extensions(11903, 3, &[&p]).unwrap();
    e.debug_grant(1, "c9_pause");
    e.debug_set_hujia(1, 3);
    e.debug_deal_damage(Some(0), 1, 2, DamageNature::Normal);
    assert!(e.open_choice().is_some());
    let s = e.save();
    let d = s
        .resolution
        .stack
        .iter()
        .find_map(|f| {
            if let engine_native::event::EventData::Damage(d) = &f.data {
                Some(d)
            } else {
                None
            }
        })
        .unwrap();
    assert_eq!(d.amount, 2);
    assert_eq!(d.settlement.committed_damage, Some(2));
    assert_eq!(d.settlement.hp_loss, 0);
    assert_eq!(e.debug_hp(1), 4);
    assert_eq!(e.state_core().player(1).hujia, 1);
    let bytes = engine_native::archive::encode_archive(&s);
    let decoded = engine_native::archive::decode_archive(&bytes).unwrap();
    assert_eq!(decoded, s);
    let restored = Engine::restore_with_extensions(&decoded, &[&p]).unwrap();
    let mut after = restored.save();
    after.auth_generation = s.auth_generation;
    assert_eq!(after, s);
    assert_eq!(e.state_hash(), restored.state_hash());
}
#[test]
fn c9_changed_root_amount_matches_damage_log_and_later_vm_context() {
    let source="skill c9_modify(99109003) { trigger damage_before owner_is_target { effect modify_current_damage(self,1); } } skill c9_pause(99109002) { trigger damage owner_is_target optional { effect draw_cards(self,1); } }";
    let p = content_compiler::compile_source_named("c9-modify", source).unwrap();
    let p = ExtensionPack {
        def: ExtensionDef {
            name: "c9-modify",
            version: 1,
            description: "actual VM before and target windows",
        },
        generals: vec![],
        cards: vec![],
        host_skills: vec![],
        vm_skills: content_native_loader::bridge_vm_skill_decls(&p)
            .unwrap()
            .decls,
        init_hook: InitHook::None,
        enabled: true,
    };
    let mut e = Engine::new_with_extensions(11904, 3, &[&p]).unwrap();
    e.debug_grant(1, "c9_modify");
    e.debug_grant(1, "c9_pause");
    e.debug_deal_damage(Some(0), 1, 1, DamageNature::Normal);
    assert_eq!(e.debug_hp(1), 2);
    let s = e.save();
    let d = s
        .resolution
        .stack
        .iter()
        .find_map(|f| match &f.data {
            engine_native::event::EventData::Damage(d) => Some(d),
            _ => None,
        })
        .unwrap();
    assert_eq!(d.amount, 2);
    assert_eq!(d.settlement.committed_damage, Some(2));
    assert!(e.log().iter().any(|x| matches!(
        x,
        engine_native::machine::LogEvent::DamageDealt { amount: 2, .. }
    )));
    let mut forged = s.clone();
    let f = forged
        .resolution
        .stack
        .iter_mut()
        .find(|f| matches!(f.data, engine_native::event::EventData::Damage(_)))
        .unwrap();
    f.stage = engine_native::event::Stage::Commit;
    assert!(Engine::restore_with_extensions(&forged, &[&p]).is_err());
}
