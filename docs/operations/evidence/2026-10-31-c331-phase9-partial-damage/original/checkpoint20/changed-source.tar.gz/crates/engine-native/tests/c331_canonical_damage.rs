use engine_native::{Engine,Phase};
use engine_native::content::extension::{ExtensionDef,ExtensionPack,InitHook};
use engine_native::event::DamageNature;
fn pack(body:&str)->ExtensionPack {
    let source=format!("skill c9_target(99109001) {{ trigger damage owner_is_target {{ {body} }} }}");
    let p=content_compiler::compile_source_named("c9-damage",&source).unwrap();
    ExtensionPack{def:ExtensionDef{name:"c9-damage",version:1,description:"real VM damage window"},generals:vec![],cards:vec![],host_skills:vec![],vm_skills:content_native_loader::bridge_vm_skill_decls(&p).unwrap().decls,init_hook:InitHook::None,enabled:true}
}
fn engine(p:&ExtensionPack)->Engine {let mut e=Engine::new_with_extensions(11901,3,&[p]).unwrap();e.debug_set_turn(0,Phase::Play,1);e.debug_grant(1,"c9_target");e}
#[test]
fn c9_cancelled_root_does_not_dispatch_target_damage() {
    let p=pack("effect draw_cards(self,1);");let mut e=engine(&p);e.state_core_mut().player_mut(1).jidong_active=true;let hand=e.state_core().player(1).hand.len();e.debug_deal_damage(Some(0),1,1,DamageNature::Normal);assert_eq!(e.state_core().player(1).hand.len(),hand,"cancelled damage has no target damage window");
}
#[test]
fn c9_target_damage_runs_before_dying_subtree() {
    let p=pack("effect recover_hp(self,1);");let mut e=engine(&p);e.debug_set_hp(1,1);e.debug_deal_damage(Some(0),1,1,DamageNature::Normal);assert_eq!(e.debug_hp(1),1,"target damage skill recovers before dying collection");assert!(e.open_choice().is_none(),"no premature rescue choice");
}
#[test]
fn c9_chain_child_does_not_overtake_parent_dying() {
    let mut e=Engine::new(11902,3);e.debug_set_turn(0,Phase::Play,1);e.debug_set_hp(1,1);e.debug_move_named_card_to_hand(0,"tao");e.state_core_mut().player_mut(1).linked=true;e.state_core_mut().player_mut(2).linked=true;e.debug_deal_damage(Some(0),1,1,DamageNature::Fire);assert!(e.open_choice().is_some(),"parent rescue is pending");assert_eq!(e.debug_hp(2),4,"chain child waits for complete parent dying subtree");
}
