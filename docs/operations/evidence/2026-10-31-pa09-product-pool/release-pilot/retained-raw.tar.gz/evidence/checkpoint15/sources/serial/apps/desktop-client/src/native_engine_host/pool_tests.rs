//! Default native owner-queue route measurements; no GUI or IPC performance claim.
use super::*;
use std::sync::mpsc;
use std::time::{Duration, Instant};

type Sample = (usize, u128);

fn measured_host() -> (
    NativeEngineHost,
    mpsc::Receiver<Sample>,
    std::thread::JoinHandle<()>,
) {
    let (sender, receiver) = sync_channel::<Job>(8);
    let closed = Arc::new(AtomicBool::new(false));
    let owner_closed = closed.clone();
    let (metrics_tx, metrics_rx) = mpsc::channel();
    let owner = std::thread::Builder::new()
        .name("desktop-engine".into())
        .spawn(move || {
            let mut host = HostSession::default();
            run_requests(receiver, &owner_closed, |request| {
                let auto = request["type"] == "autoStep";
                let before = host.session.as_ref().map_or(0, |_| 0usize);
                let started = Instant::now();
                let result = host.dispatch(request);
                if auto {
                    let after = 0usize;
                    metrics_tx
                        .send((after - before, started.elapsed().as_nanos()))
                        .unwrap();
                }
                result
            });
        })
        .unwrap();
    (
        NativeEngineHost {
            sender: Mutex::new(Some(sender)),
            closed,
        },
        metrics_rx,
        owner,
    )
}

fn verify_raw_rows(rows: &[Value], summary: &Value, variant: &str) {
    let requests: Vec<_> = rows.iter().filter(|row| row["kind"] == "request").collect();
    assert_eq!(requests.len(), 1687);
    for (index, row) in requests.iter().enumerate() {
        assert_eq!(row["request_id"].as_u64(), Some(index as u64 + 1));
        assert_eq!(row["variant"], variant);
        if row["request_type"] == "autoStep" {
            assert!(row["hash_hex"]
                .as_str()
                .is_some_and(|hash| hash.len() == 64));
        }
    }
    for game in 0..6 {
        let steps: Vec<_> = requests
            .iter()
            .filter(|row| row["request_type"] == "autoStep" && row["game_index"] == game)
            .collect();
        assert_eq!(steps.len(), 280, "whole-game row count");
        for (index, row) in steps.iter().enumerate() {
            assert_eq!(row["step_index"].as_u64(), Some(index as u64));
        }
        assert_eq!(steps.last().unwrap()["finished"], true);
    }
    let measured: Vec<_> = requests
        .iter()
        .filter(|row| row["request_type"] == "autoStep" && row["warmup"] == false)
        .collect();
    assert_eq!(measured.len(), 1400);
    let jobs: u64 = measured
        .iter()
        .map(|row| row["accepted_jobs_delta"].as_u64().unwrap())
        .sum();
    let pool_steps = measured
        .iter()
        .filter(|row| row["accepted_jobs_delta"].as_u64().unwrap() > 0)
        .count();
    assert_eq!(summary["samples"].as_u64(), Some(measured.len() as u64));
    assert_eq!(summary["accepted_candidate_jobs"].as_u64(), Some(jobs));
    assert_eq!(summary["pool_steps"].as_u64(), Some(pool_steps as u64));
    if variant == "candidate" {
        assert!(jobs > 0);
    } else {
        assert_eq!(variant, "serial");
        assert_eq!(jobs, 0);
    }
}

#[tokio::test]
#[ignore = "release default native owner-queue raw-row experiment; run explicitly"]
async fn actual_default_auto_step_owner_queue_measurement() {
    let metadata: Value = serde_json::from_str(
        &std::env::var("PA09_MEASUREMENT_METADATA").expect("test-run metadata"),
    )
    .unwrap();
    let variant = metadata["variant"].as_str().unwrap();
    let abba_run = metadata["abba_run"].as_u64().unwrap();
    assert_eq!(metadata["profile"], "release");
    let (host, metrics, owner) = measured_host();
    let mut rows = Vec::with_capacity(1689);
    let started = Instant::now();
    let init = host.request(json!({"id":1,"type":"init"})).await.unwrap();
    let init_ns = started.elapsed().as_nanos();
    assert_eq!(init["ok"], true);
    rows.push(json!({"kind":"request","variant":variant,"abba_run":abba_run,
        "profile":"release","source_identity":metadata["source_identity"],"binary_sha256":metadata["binary_sha256"],
        "game_index":null,"step_index":null,"request_id":1,"request_type":"init","warmup":true,
        "accepted_jobs_delta":0,"roundtrip_ns":init_ns,"owner_ns":null,"hash_hex":null}));
    let mut id = 2;
    let mut submitted = 0;
    let mut pool_steps = 0;
    let mut completed_games = 0;
    let mut trajectory = blake3::Hasher::new();
    for game in 0..6 {
        let started = Instant::now();
        let start = host.request(json!({"id":id,"type":"start","players":4,"seed":42,"observer":0,"mode":"identity"})).await.unwrap();
        let start_ns = started.elapsed().as_nanos();
        assert_eq!(start["ok"], true);
        rows.push(json!({"kind":"request","variant":variant,"abba_run":abba_run,
            "profile":"release","source_identity":metadata["source_identity"],"binary_sha256":metadata["binary_sha256"],
            "game_index":game,"step_index":null,"request_id":id,"request_type":"start","warmup":game==0,
            "accepted_jobs_delta":0,"roundtrip_ns":start_ns,"owner_ns":null,"hash_hex":start["data"]["hash_hex"]}));
        id += 1;
        for step in 0..1500 {
            let started = Instant::now();
            let response = host
                .request(json!({"id":id,"type":"autoStep"}))
                .await
                .unwrap();
            let elapsed = started.elapsed().as_nanos();
            assert_eq!(response["ok"], true, "{response}");
            let (jobs, compute) = metrics.recv_timeout(Duration::from_secs(2)).unwrap();
            rows.push(json!({"kind":"request","variant":variant,"abba_run":abba_run,
                "profile":"release","source_identity":metadata["source_identity"],"binary_sha256":metadata["binary_sha256"],
                "game_index":game,"step_index":step,"request_id":id,"request_type":"autoStep","warmup":game==0,
                "accepted_jobs_delta":jobs,"roundtrip_ns":elapsed,"owner_ns":compute,
                "hash_hex":response["data"]["hash_hex"],"finished":response["data"]["finished"]}));
            id += 1;
            if game > 0 {
                submitted += jobs;
                pool_steps += usize::from(jobs > 0);
                trajectory.update(&serde_json::to_vec(&response["data"]).unwrap());
            }
            if response["data"]["finished"] == true {
                if game > 0 {
                    completed_games += 1;
                }
                break;
            }
        }
    }
    let retirement = Instant::now();
    host.close();
    let close_ns = retirement.elapsed().as_nanos();
    owner.join().unwrap();
    let retire_total_ns = retirement.elapsed().as_nanos();
    let summary = json!({"kind":"summary","variant":variant,"abba_run":abba_run,"profile":"release",
        "source_identity":metadata["source_identity"],"binary_sha256":metadata["binary_sha256"],
        "route":"NativeEngineHost::request/run_requests/HostSession::dispatch/NativeSession::auto_step/envelope",
        "players":4,"seed":42,"nodes":64,"deadline_ms":50,"samples":1400,"completed_games":completed_games,
        "accepted_candidate_jobs":submitted,"pool_steps":pool_steps,"warmup_games":1,
        "trajectory_digest":trajectory.finalize().to_hex().to_string(),
        "close_ns":close_ns,"retire_total_ns":retire_total_ns,
        "limitations":"actual Rust owner queue/dispatch/envelope; no Tauri ResourceTable/WebView/IPC; accepted is not executed; first no-job step may create pool"});
    println!("{}", json!({"kind":"metadata","metadata":metadata}));
    for row in &rows {
        println!("{row}");
    }
    println!("{summary}");
    verify_raw_rows(&rows, &summary, variant);
    assert_eq!(completed_games, 5);
}
