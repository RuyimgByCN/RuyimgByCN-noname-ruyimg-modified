use engine_native::content::extension::{ExtensionDef, ExtensionPack, InitHook};
use engine_native::event::{DamageNature, DamageOutcome, DamageProgress, EventData, EventKind};
use engine_native::{ChoiceOption, CommandOutcome, Engine, GameAction, GameCommand};

fn package(source: &str, bindings: &[(&str, EventKind)]) -> ExtensionPack {
    let raw = content_compiler::compile_source_named("c9b", source).unwrap();
    let mut decls = content_native_loader::bridge_vm_skill_decls(&raw)
        .unwrap()
        .decls;
    for (name, kind) in bindings {
        decls
            .iter_mut()
            .find(|d| d.name == *name)
            .unwrap()
            .trigger
            .event = *kind;
    }
    ExtensionPack {
        def: ExtensionDef {
            name: "c9b",
            version: 1,
            description: "actual declared damage windows",
        },
        generals: vec![],
        cards: vec![],
        host_skills: vec![],
        vm_skills: decls,
        init_hook: InitHook::None,
        enabled: true,
    }
}
fn answer(e: &mut Engine, selection: Vec<ChoiceOption>) {
    let c = e.open_choice().unwrap().clone();
    let out = e.submit(GameCommand {
        actor: c.observer,
        expected_revision: e.revision(),
        dedup_id: e.revision() + 1,
        action: GameAction::Answer {
            choice_id: c.id,
            selection,
        },
    });
    assert!(!matches!(out, CommandOutcome::Rejected(_)), "{out:?}");
}
fn restore(e: &Engine, p: &ExtensionPack) -> Engine {
    let s = e.save();
    let bytes = engine_native::archive::encode_archive(&s);
    let decoded = engine_native::archive::decode_archive(&bytes).unwrap();
    assert_eq!(decoded, s);
    let r = Engine::restore_with_extensions(&decoded, &[p]).unwrap();
    let mut normalized = r.save();
    normalized.auth_generation = s.auth_generation;
    assert_eq!(normalized, s);
    assert_eq!(e.state_hash(), r.state_hash());
    assert!(
        r.log().is_empty(),
        "restore starts a fresh runtime log; compare continuation suffixes"
    );
    r
}
fn same(a: &Engine, b: &Engine) {
    let mut sa = a.save();
    let mut sb = b.save();
    sa.auth_generation = 0;
    sb.auth_generation = 0;
    assert_eq!(sa, sb);
    assert_eq!(a.state_hash(), b.state_hash());
    assert!(
        a.log().ends_with(b.log()),
        "restored continuation events must match the original suffix"
    );
}
#[test]
fn c9b_every_pre_hp_window_roundtrips_and_modifies_one_canonical_root() {
    let p=package("skill c9b_a(99109111) { trigger damage_before owner_is_target optional { effect modify_current_damage(self,1); } } skill c9b_b(99109112) { trigger damage_before owner_is_target optional { effect modify_current_damage(self,1); } } skill c9b_c(99109113) { trigger damage_before owner_is_target optional { effect modify_current_damage(self,1); } } skill c9b_d(99109114) { trigger damage_before owner_is_target optional { effect modify_current_damage(self,1); } } skill c9b_e(99109115) { trigger damage_before owner_is_target optional { effect modify_current_damage(self,1); } } skill c9b_f(99109116) { trigger damage_before owner_is_target optional { effect modify_current_damage(self,1); } } skill c9b_t(99109117) { trigger damage owner_is_target optional { effect draw_cards(self,event_amount); } }",&[("c9b_b",EventKind::DamageBegin),("c9b_c",EventKind::DamageBegin1),("c9b_d",EventKind::DamageBegin2),("c9b_e",EventKind::DamageBegin3),("c9b_f",EventKind::DamageBegin4)]);
    let mut e = Engine::new_with_extensions(12011, 3, &[&p]).unwrap();
    e.debug_set_max_hp(1, 20);
    e.debug_set_hp(1, 20);
    for name in [
        "c9b_a", "c9b_b", "c9b_c", "c9b_d", "c9b_e", "c9b_f", "c9b_t",
    ] {
        e.debug_grant(1, name);
    }
    e.debug_deal_damage(Some(0), 1, 1, DamageNature::Normal);
    for (i, kind) in [
        EventKind::DamageBefore,
        EventKind::DamageBegin,
        EventKind::DamageBegin1,
        EventKind::DamageBegin2,
        EventKind::DamageBegin3,
        EventKind::DamageBegin4,
        EventKind::Damage,
    ]
    .into_iter()
    .enumerate()
    {
        let s = e.save();
        let root = s
            .resolution
            .stack
            .iter()
            .find(|f| matches!(f.data, EventData::Damage(_)))
            .unwrap();
        let d = root.damage();
        assert_eq!(d.amount, 1 + i as i32);
        assert_eq!(
            d.settlement.committed_damage,
            if i == 6 { Some(7) } else { None }
        );
        assert_eq!(e.debug_hp(1), if i == 6 { 13 } else { 20 });
        let window = s
            .resolution
            .stack
            .iter()
            .find(|f| matches!(f.data, EventData::DamageWindow { .. }))
            .unwrap();
        assert_eq!(window.parent, Some(root.id));
        assert_eq!(window.kind, kind);
        let mut r = restore(&e, &p);
        let before = e.save();
        let mut forged = before.clone();
        let root = forged
            .resolution
            .stack
            .iter_mut()
            .find(|f| matches!(f.data, EventData::Damage(_)))
            .unwrap();
        root.damage_mut().settlement.outcome = DamageOutcome::Completed;
        assert!(Engine::restore_with_extensions(&forged, &[&p]).is_err());
        assert_eq!(e.save(), before);
        answer(&mut e, vec![ChoiceOption::Confirm]);
        answer(&mut r, vec![ChoiceOption::Confirm]);
        same(&e, &r);
    }
    assert!(e.open_choice().is_none());
    assert_eq!(e.debug_hp(1), 13);
    assert_eq!(
        e.log()
            .iter()
            .filter(|x| matches!(
                x,
                engine_native::machine::LogEvent::DamageDealt { amount: 7, .. }
            ))
            .count(),
        1
    );
}
#[test]
fn c9b_post_submit_zero_stops_source_end_after_but_keeps_receipt() {
    let p=package("skill c9b_stop(99109121) { trigger damage_before owner_is_target { effect modify_current_damage(self,-2); } } skill c9b_zero(99109122) { trigger damage owner_is_target optional { effect draw_cards(self,1); } } skill c9b_end(99109123) { trigger damage owner_is_target { effect draw_cards(self,9); } }",&[("c9b_stop",EventKind::Damage),("c9b_zero",EventKind::DamageZero),("c9b_end",EventKind::DamageEnd)]);
    let mut e = Engine::new_with_extensions(12021, 3, &[&p]).unwrap();
    for name in ["c9b_stop", "c9b_zero", "c9b_end"] {
        e.debug_grant(1, name);
    }
    let h = e.debug_hand(1).len();
    e.debug_deal_damage(Some(0), 1, 2, DamageNature::Normal);
    assert_eq!(e.debug_hp(1), 2);
    let s = e.save();
    let d = s
        .resolution
        .stack
        .iter()
        .find(|f| matches!(f.data, EventData::Damage(_)))
        .unwrap()
        .damage();
    assert_eq!(d.amount, 0);
    assert_eq!(d.settlement.committed_damage, Some(2));
    assert_eq!(d.settlement.hp_loss, 2);
    assert_eq!(d.settlement.outcome, DamageOutcome::Zero);
    assert_eq!(d.settlement.progress, DamageProgress::Stopped);
    let mut r = restore(&e, &p);
    answer(&mut e, vec![ChoiceOption::Confirm]);
    answer(&mut r, vec![ChoiceOption::Confirm]);
    same(&e, &r);
    assert_eq!(e.debug_hand(1).len(), h + 1);
}
#[test]
fn c9b_source_death_is_cleared_before_end_and_restore() {
    let p=package("skill c9b_kill(99109131) { trigger damage owner_is_source { effect lose_hp(self,1); } } skill c9b_end(99109132) { trigger damage owner_is_target optional { effect draw_cards(self,event_amount); } }",&[("c9b_kill",EventKind::DamageSource),("c9b_end",EventKind::DamageEnd)]);
    let mut e = Engine::new_with_extensions(12031, 3, &[&p]).unwrap();
    e.debug_grant(0, "c9b_kill");
    e.debug_grant(1, "c9b_end");
    for p in 0..3 {
        e.debug_clear_hand(p);
    }
    e.debug_set_hp(0, 1);
    e.debug_deal_damage(Some(0), 1, 2, DamageNature::Normal);
    assert!(!e.debug_alive(0));
    assert_eq!(e.open_choice().unwrap().spec.prompt, "trigger_confirm");
    let s = e.save();
    let d = s
        .resolution
        .stack
        .iter()
        .find(|f| matches!(f.data, EventData::Damage(_)))
        .unwrap()
        .damage();
    assert_eq!(d.source, None);
    assert_eq!(d.amount, 2);
    let mut r = restore(&e, &p);
    answer(&mut e, vec![ChoiceOption::Confirm]);
    answer(&mut r, vec![ChoiceOption::Confirm]);
    same(&e, &r);
    assert_eq!(e.debug_hand(1).len(), 2);
}
#[test]
fn c9b_notrigger_suppresses_windows_without_suppressing_submission() {
    let p=package("skill c9b_watch(99109141) { trigger damage owner_is_target { effect draw_cards(self,9); } }",&[]);
    let mut e = Engine::new_with_extensions(12041, 3, &[&p]).unwrap();
    e.debug_grant(1, "c9b_watch");
    let mut core = e.save().core;
    let mut res = engine_native::resolution::Resolution::new(10000);
    let mut logs = Vec::new();
    let mut d = engine_native::machine::damage_data(Some(0), 1, 2);
    d.settlement.notrigger = true;
    let id = engine_native::resolution::push_frame(&mut res, EventData::Damage(d));
    let hand = core.player(1).hand.len();
    let mut submitted = false;
    for _ in 0..200 {
        let out =
            engine_native::resolution::run(&mut core, &mut res, e.catalog(), &mut logs, Some(1));
        if let Some(root) = res.frame(id) {
            let d = root.damage();
            if d.settlement.committed_damage == Some(2) {
                submitted = true;
                assert_eq!(d.amount, 2);
                assert_eq!(d.settlement.hp_loss, 2);
            }
        }
        assert!(!matches!(
            out,
            engine_native::resolution::StepOutcome::Fault
                | engine_native::resolution::StepOutcome::Pending
        ));
        if out == engine_native::resolution::StepOutcome::Done {
            break;
        }
    }
    assert!(submitted);
    assert!(res.stack.is_empty());
    assert_eq!(core.player(1).hp, 2);
    assert_eq!(core.player(1).hand.len(), hand);
}

#[test]
fn c9b_submission_slice_restore_does_not_commit_twice_and_rejects_completed_progress() {
    let mut p=package("skill c9b_multi(99109151) { trigger damage_before owner_is_target { effect draw_cards(self,1); } trigger damage_before owner_is_target { effect draw_cards(self,1); } }",&[]);
    for decl in &mut p.vm_skills {
        decl.trigger.event = EventKind::DamageBegin2;
        if let engine_native::rvm_bridge::VmFilterPolicy::Handlers(set) = &mut decl.filter {
            for handler in &mut std::sync::Arc::make_mut(set).triggers {
                handler.meta.event = EventKind::DamageBegin2;
            }
        }
    }
    let mut e = Engine::new_with_extensions(12051, 3, &[&p]).unwrap();
    e.debug_set_turn(0, engine_native::Phase::Play, 1);
    e.debug_grant(1, "c9b_multi");
    e.debug_clear_hand(1);
    let card = e.debug_place(0, "sha");
    e.set_time_slice(Some(1));
    e.submit(GameCommand {
        actor: 0,
        expected_revision: e.revision(),
        dedup_id: e.revision() + 1,
        action: GameAction::PlayCard {
            card,
            targets: vec![1],
        },
    });
    let mut branch = None;
    let mut saw_submission = false;
    let mut checked_matrix = false;
    let mut saw_following = false;
    for _ in 0..300 {
        let s = e.save();
        if s.resolution
            .stack
            .iter()
            .any(|f| matches!(f.data, EventData::DamageWindow { .. }))
            && s.resolution.open_choice.is_none()
        {
            let mut invalid = s.clone();
            if let Some(driver) = invalid.resolution.parks.iter_mut().find(|park| {
                matches!(
                    park.machine,
                    engine_native::snap::MachineSnapshot::DamageFlow { .. }
                )
            }) {
                driver.resume_depth += 1;
                assert!(Engine::restore_with_extensions(&invalid, &[&p]).is_err());
                assert_eq!(e.save(), s);
            }
        }

        if s.resolution.parks.iter().any(|park|matches!(&park.machine,engine_native::snap::MachineSnapshot::Rvm{following,..}if !following.is_empty())) {let _=restore(&e,&p);saw_following=true;}

        if let Some(root) = s
            .resolution
            .stack
            .iter()
            .find(|f| matches!(f.data, EventData::Damage(_)))
        {
            let d = root.damage();
            if d.settlement.progress == DamageProgress::SubmitHp {
                saw_submission = true;
                assert_eq!(d.settlement.committed_damage, None);
                assert_eq!(e.debug_hp(1), 4);
                let mut r = restore(&e, &p);
                r.set_time_slice(None);
                assert!(!matches!(r.resume(), CommandOutcome::Rejected(_)));
                branch = Some(r);
            }
            if matches!(d.settlement.progress, DamageProgress::HpCommitted { .. }) {
                assert_eq!(d.amount, 1);
                assert_eq!(d.settlement.committed_damage, Some(1));
                assert_eq!(d.settlement.hp_loss, 1);
                let mut invalid = s.clone();
                let d = invalid
                    .resolution
                    .stack
                    .iter_mut()
                    .find(|f| matches!(f.data, EventData::Damage(_)))
                    .unwrap()
                    .damage_mut();
                d.settlement.outcome = DamageOutcome::Completed;
                assert!(Engine::restore_with_extensions(&invalid, &[&p]).is_err());
                assert_eq!(e.save(), s);
                checked_matrix = true;
            }
        }
        if s.resolution.stack.is_empty() && !s.segment_open {
            break;
        }
        assert!(!matches!(e.resume(), CommandOutcome::Rejected(_)));
    }
    assert!(
        saw_submission && checked_matrix && saw_following,
        "submission={saw_submission} matrix={checked_matrix} following={saw_following}"
    );
    let r = branch.unwrap();
    same(&e, &r);
    assert_eq!(e.debug_hp(1), 3);
    assert_eq!(e.state_core().player(1).hujia, 0);
    assert_eq!(
        e.log()
            .iter()
            .filter(|x| matches!(x, engine_native::machine::LogEvent::DamageDealt { .. }))
            .count(),
        1
    );
}
#[test]
fn c9b_dead_parent_keeps_chain_eligibility_and_siblings_unlink_on_their_own_submission() {
    let p=package("skill c9b_chain_pause(99109161) { trigger damage_before owner_is_target optional { effect draw_cards(self,1); } }",&[]);
    let mut e = Engine::new_with_extensions(12061, 4, &[&p]).unwrap();
    e.debug_grant(2, "c9b_chain_pause");
    for player in 0..4 {
        e.debug_clear_hand(player);
    }
    e.debug_set_hp(1, 1);
    for player in [1, 2, 3] {
        e.state_core_mut().player_mut(player).linked = true;
    }
    e.debug_deal_damage(Some(0), 1, 1, DamageNature::Fire);
    assert!(!e.debug_alive(1));
    assert!(!e.state_core().player(1).linked);
    assert!(e.state_core().player(2).linked);
    assert!(e.state_core().player(3).linked);
    assert_eq!(e.debug_hp(2), 4);
    assert_eq!(e.debug_hp(3), 4);
    let mut r = restore(&e, &p);
    answer(&mut e, vec![]);
    answer(&mut r, vec![]);
    same(&e, &r);
    assert_eq!(e.debug_hp(2), 3);
    assert_eq!(e.debug_hp(3), 3);
    assert!(!e.state_core().player(2).linked);
    assert!(!e.state_core().player(3).linked);
}
#[test]
fn c9b_post_submit_cancel_has_a_real_cancelled_child_without_zero_or_end() {
    let p=package("skill c9b_cancel(99109171) { trigger damage_before owner_is_target { effect prevent_current_damage(); } } skill c9b_cancelled(99109172) { trigger damage owner_is_target optional { effect draw_cards(self,1); } } skill c9b_end(99109173) { trigger damage owner_is_target { effect draw_cards(self,9); } }",&[("c9b_cancel",EventKind::Damage),("c9b_cancelled",EventKind::DamageCancelled),("c9b_end",EventKind::DamageEnd)]);
    let mut e = Engine::new_with_extensions(12071, 3, &[&p]).unwrap();
    for name in ["c9b_cancel", "c9b_cancelled", "c9b_end"] {
        e.debug_grant(1, name);
    }
    let h = e.debug_hand(1).len();
    e.debug_deal_damage(Some(0), 1, 2, DamageNature::Normal);
    let s = e.save();
    let root = s
        .resolution
        .stack
        .iter()
        .find(|f| matches!(f.data, EventData::Damage(_)))
        .unwrap();
    assert_eq!(root.damage().settlement.committed_damage, Some(2));
    assert_eq!(root.damage().settlement.outcome, DamageOutcome::Cancelled);
    assert!(s
        .resolution
        .stack
        .iter()
        .any(|f| matches!(f.data, EventData::DamageWindow { .. })
            && f.kind == EventKind::DamageCancelled));
    let mut r = restore(&e, &p);
    answer(&mut e, vec![ChoiceOption::Confirm]);
    answer(&mut r, vec![ChoiceOption::Confirm]);
    same(&e, &r);
    assert_eq!(e.debug_hp(1), 2);
    assert_eq!(e.debug_hand(1).len(), h + 1);
}
#[test]
fn c9b_replacement_waits_for_real_lose_hp_and_dying_children_across_restore() {
    let p=package("skill c9b_unused(99109181) { trigger damage owner_is_target { effect draw_cards(self,9); } }",&[]);
    let mut e = Engine::new_with_extensions(12081, 3, &[&p]).unwrap();
    e.debug_grant(0, "绝情");
    e.debug_grant(1, "c9b_unused");
    e.debug_set_hp(1, 1);
    for player in 0..3 {
        e.debug_clear_hand(player);
    }
    e.debug_move_named_card_to_hand(0, "tao");
    e.debug_deal_damage(Some(0), 1, 1, DamageNature::Normal);
    assert_eq!(e.open_choice().unwrap().spec.prompt, "dying_save");
    let s = e.save();
    let root = s
        .resolution
        .stack
        .iter()
        .find(|f| matches!(f.data, EventData::Damage(_)))
        .unwrap();
    assert_eq!(
        root.damage().settlement.outcome,
        DamageOutcome::ReplacedByLoseHp
    );
    assert_eq!(root.damage().settlement.committed_damage, None);
    assert!(s
        .resolution
        .stack
        .iter()
        .any(|f| matches!(f.data, EventData::LoseHp { .. })));
    let mut r = restore(&e, &p);
    for game in [&mut e, &mut r] {
        while game.open_choice().is_some() {
            answer(game, vec![ChoiceOption::Pass]);
        }
    }
    same(&e, &r);
    assert!(!e.debug_alive(1));
    assert!(!e
        .log()
        .iter()
        .any(|x| matches!(x, engine_native::machine::LogEvent::DamageDealt { .. })));
}
