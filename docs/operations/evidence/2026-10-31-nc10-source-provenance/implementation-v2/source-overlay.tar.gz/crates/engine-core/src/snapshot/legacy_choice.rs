//! Archive-only source stripping; wire ChoiceRequest keeps its strict validator.
use engine_api::ChoiceRequest;
use serde::{
    de::{self, DeserializeSeed, IgnoredAny, MapAccess, SeqAccess, Visitor},
    Deserialize, Deserializer, Serialize, Serializer,
};
use std::fmt;

pub(crate) fn without_source(choice: &Option<ChoiceRequest>) -> Option<ChoiceRequest> {
    choice.clone().map(|mut choice| {
        choice.source_skill = None;
        choice
    })
}
pub(super) fn serialize<S: Serializer>(
    choice: &Option<ChoiceRequest>,
    serializer: S,
) -> Result<S::Ok, S::Error> {
    without_source(choice).serialize(serializer)
}
pub(super) fn deserialize<'de, D: Deserializer<'de>>(
    deserializer: D,
) -> Result<Option<ChoiceRequest>, D::Error> {
    struct Optional;
    impl<'de> Visitor<'de> for Optional {
        type Value = Option<ChoiceRequest>;
        fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
            f.write_str("an optional legacy choice")
        }
        fn visit_none<E: de::Error>(self) -> Result<Self::Value, E> {
            Ok(None)
        }
        fn visit_unit<E: de::Error>(self) -> Result<Self::Value, E> {
            Ok(None)
        }
        fn visit_some<D: Deserializer<'de>>(
            self,
            deserializer: D,
        ) -> Result<Self::Value, D::Error> {
            deserializer
                .deserialize_struct("ChoiceRequest", &[], Choice)
                .map(Some)
        }
    }
    deserializer.deserialize_option(Optional)
}
struct Choice;
impl<'de> Visitor<'de> for Choice {
    type Value = ChoiceRequest;
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("a legacy choice map")
    }
    fn visit_seq<S: SeqAccess<'de>>(self, sequence: S) -> Result<Self::Value, S::Error> {
        ChoiceRequest::deserialize(de::value::SeqAccessDeserializer::new(LegacySequence {
            sequence,
            remaining: 13,
        }))
    }
    fn visit_map<M: MapAccess<'de>>(self, map: M) -> Result<Self::Value, M::Error> {
        ChoiceRequest::deserialize(de::value::MapAccessDeserializer::new(WithoutSource(map)))
    }
}
struct WithoutSource<M>(M);
impl<'de, M: MapAccess<'de>> MapAccess<'de> for WithoutSource<M> {
    type Error = M::Error;
    fn next_key_seed<K: DeserializeSeed<'de>>(
        &mut self,
        seed: K,
    ) -> Result<Option<K::Value>, Self::Error> {
        loop {
            let Some(key) = self.0.next_key::<String>()? else {
                return Ok(None);
            };
            if key == "source_skill" {
                // Discard before the shared String validator; retain all other duplicate keys.
                self.0.next_value::<IgnoredAny>()?;
            } else {
                return seed
                    .deserialize(de::value::StringDeserializer::<M::Error>::new(key))
                    .map(Some);
            }
        }
    }
    fn next_value_seed<V: DeserializeSeed<'de>>(
        &mut self,
        seed: V,
    ) -> Result<V::Value, Self::Error> {
        self.0.next_value_seed(seed)
    }
}

// Serde also accepts positional structs; retain the original 13-field length.
struct LegacySequence<S> {
    sequence: S,
    remaining: usize,
}
impl<'de, S: SeqAccess<'de>> SeqAccess<'de> for LegacySequence<S> {
    type Error = S::Error;
    fn next_element_seed<T: DeserializeSeed<'de>>(
        &mut self,
        seed: T,
    ) -> Result<Option<T::Value>, Self::Error> {
        if self.remaining == 0 {
            return Ok(None);
        }
        self.remaining -= 1;
        self.sequence.next_element_seed(seed)
    }
}
