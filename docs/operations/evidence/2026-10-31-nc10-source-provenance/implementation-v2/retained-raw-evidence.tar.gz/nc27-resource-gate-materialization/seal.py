import hashlib,json,os,pathlib,subprocess,time
W=pathlib.Path.cwd().resolve();E=W.parent/'evidence';D=E/'nc27-resource-gate-materialization';F=E/'final-freeze-v2'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def sig(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode,s.st_nlink]
a=json.loads((D/'after.json').read_text());b=json.loads((D/'before.json').read_text());f=json.loads((F/'source-manifest.json').read_text());by={i['path']:i for i in f['files']}
keys=json.loads((W/'docs/operations/evidence/2026-10-30-up37-i02-audio-compat/parent-main-source-admission.json').read_text())['source14'].keys();assert len(keys)==14
records=[]
for p in keys:
 expected=by[p]['sha256'];work=sha(W/p);frozen=sha(F/'source'/p);assert expected==work==frozen
 before=b['tracked_stats'][p];after=a['tracked_stats'][p];current=sig(W/p);assert after==current
 if p!='content/original/asset-manifest.json':assert before==after
 else:assert b['pins']['protected:'+p]==work
 records.append({'path':p,'expected_frozen_sha256':expected,'work_sha256':work,'frozen_sha256':frozen,'before_stat':before,'after_stat':after,'final_stat':current,'before_sha_evidence':'individually hashed before/after' if ('protected:'+p in b['pins'] or 'work:'+p in b['pins']) else 'unchanged before/after/final stat ledger; final hash matches frozen'})
for i in f['files']:
 if i['changed']:assert sha(W/i['path'])==sha(F/'source'/i['path'])==i['sha256']
assert all(sig(W/p)==s for p,s in a['tracked_stats'].items())
for key,h in a['pins'].items():
 if key.startswith('protected:'):assert sha(W/key.removeprefix('protected:'))==h
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();staged=subprocess.check_output(['git','diff','--cached','--name-only']).decode();assert not staged and head==a['head']
assert sha(F/'source-manifest.json')=='48b6fa497c0ba22f512726a9566e496f5801b04e895c65ec725e8a66f3d0421e'
results={n:json.loads((E/(n+'.json')).read_text()) for n in ['v2-original-sync-verify','nc27-resource-gate-refresh','nc27-resource-gate-verify','nc27-original-sync-verify-repaired']};assert results['v2-original-sync-verify']['exit']==1;assert all(r['exit']==0 for n,r in results.items() if n!='v2-original-sync-verify')
report={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'head':head,'no_staged_files':not staged,'source31_manifest_sha256':sha(F/'source-manifest.json'),'source31_work_and_frozen_match':True,'all_tracked_final_stats_equal_after':True,'protected_sha_final_match':True,'direct14':records,'compat_count':6,'direct14_scope_note':'14 path set recovered after refresh; hashes use current 4dd frozen manifest, not historical values; unchanged stat ledgers link current content to before except manifest which has explicit before/after SHA','results':results,'command_environment':{'GIT_OPTIONAL_LOCKS':'0','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(W.parent/'target'),'NONAME_ORIGINAL_ROOT':'unset','skin_source':'unset','cwd':str(W),'node':subprocess.check_output(['which','node']).decode().strip(),'node_version':subprocess.check_output(['node','--version']).decode().strip(),'global_lock':'/tmp/noname-phase4-heavy-command.lock','inherited_environment':'not dumped; only task-relevant nonsecret overrides recorded'},'original_failure_sha256':sha(E/'v2-original-sync-verify.log')}
(D/'final-seal.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='direct14'},indent=2))
