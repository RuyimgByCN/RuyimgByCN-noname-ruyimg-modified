import hashlib, json, os, pathlib, stat, subprocess, sys, time
W=pathlib.Path.cwd().resolve(); E=W.parent/'evidence'; D=E/'nc27-resource-gate-materialization'; F=E/'final-freeze-v2'
S=(W/'../archive/upstream/noname/apps/core').resolve(); A=W/'content/original/assets'
phase=sys.argv[1]; assert phase in ('before','after')
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()
def git(*args,cwd=W):
 return subprocess.check_output(['git',*args],cwd=cwd,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).decode().strip()
def sig(p):
 s=p.lstat(); return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns,s.st_mode,s.st_nlink]
def safe_tree(root):
 assert root.is_dir() and not root.is_symlink(),str(root)
 out=[]
 for parent,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=pathlib.Path(parent)/name; info=p.lstat()
   assert not stat.S_ISLNK(info.st_mode),str(p)
   assert stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode),str(p)
  out += [str((pathlib.Path(parent)/f).relative_to(root)) for f in files]
 return sorted(out)
manifest_file=W/'content/original/asset-manifest.json'; manifest=json.loads(manifest_file.read_text()); freeze=json.loads((F/'source-manifest.json').read_text())
assert digest(F/'source-manifest.json')=='48b6fa497c0ba22f512726a9566e496f5801b04e895c65ec725e8a66f3d0421e'
assert git('rev-parse','HEAD')=='4dd0b286b995fe414128b6c52eb83a4d0d85f6cd'
assert not git('diff','--cached','--name-only')
assert not git('-C',str(S),'status','--porcelain=v1','--untracked-files=all','--','.')
assert git('-C',str(S),'rev-parse','HEAD')==manifest['sources']['core']['head']
tracked=git('ls-files','-z').rstrip('\0').split('\0')
allowed=[A/n for n in ['portraits','audio','audio-compat','audio-declared']]
for root in allowed:
 assert root.resolve()==root and root.is_relative_to(W) and not root.is_relative_to(S)
 assert not any(t==str(root.relative_to(W)) or t.startswith(str(root.relative_to(W))+'/') for t in tracked)
 assert subprocess.run(['git','check-ignore','-q',str(root.relative_to(W))]).returncode==0
 for p in [root,*list(root.parents)[:3]]: assert p.is_dir() and not p.is_symlink(),str(p)
 safe_tree(root)
assert manifest_file.lstat().st_nlink==1 and not manifest_file.is_symlink()
changed=[i for i in freeze['files'] if i['changed']]; assert len(changed)==31
compat=[i for i in freeze['files'] if i['path'].startswith('content/original-audio-compat/')]
pins={}
for i in changed+compat:
 for root,label in [(W,'work'),(F/'source','frozen')]:
  p=root/i['path']; actual=digest(p); assert actual==i['sha256'],str(p)
  pins[label+':'+i['path']]=actual
assert digest(W/'content/original-audio-compat/provenance.json')=='1bd98a3e5d7ab22f6749b132d041f409e95a0dbf2f7ed9a603ec256422cc5313'
protected=set(['content/original/asset-manifest.json','content/original/catalog.json'])
protected.update(t for t in tracked if pathlib.Path(t).name in {'package.json','package-lock.json','pnpm-lock.yaml','yarn.lock','Cargo.toml','Cargo.lock'} or t.startswith('content/original/packages/') or t.startswith('content/original/ported/'))
for t in protected: pins['protected:'+t]=digest(W/t)
for label,root in [('private',W),('upstream',S)]:
 index=pathlib.Path(git('rev-parse','--path-format=absolute','--git-path','index',cwd=root)); pins[label+':git-index']=digest(index)
cache={}
cache_path=D/'source-hash-cache.json'
if phase=='after': cache=json.loads(cache_path.read_text())
def file_tuple(p):
 s=p.stat(); key=f'{s.st_dev}:{s.st_ino}:{s.st_size}:{s.st_mtime_ns}'
 if key not in cache: cache[key]=digest(p)
 return {'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':cache[key]}
trees=[('legacy-source',S/'character',W/'content/original/legacy-source/character',False),('portraits',S/'image/character',A/'portraits',True),('audio',S/'audio',A/'audio',True),('audio-compat',W/'content/original-audio-compat/audio',A/'audio-compat',False)]
summaries=[]; discrepancies=[]; hash_totals={}; direct={}
with (D/f'{phase}-pairs.jsonl').open('x') as log:
 for name,src,dst,hardlink in trees:
  sf=safe_tree(src); tf=safe_tree(dst); assert sf==tf,name
  summary={'name':name,'source_category':'compat' if name=='audio-compat' else 'core','files':len(sf),'bytes':0,'hardlinked':0,'copied':0}; hashes=hashlib.sha256()
  for rel in sf:
   a=file_tuple(src/rel); b=file_tuple(dst/rel); assert a['size']==b['size'] and a['sha256']==b['sha256'],(name,rel)
   same=(a['dev'],a['ino'])==(b['dev'],b['ino']); summary['hardlinked' if same else 'copied']+=1; summary['bytes']+=a['size']
   hashes.update((rel+'\0'+a['sha256']+'\n').encode())
   log.write(json.dumps({'tree':name,'relative':rel,'source':str(src/rel),'target':str(dst/rel),'source_tuple':a,'target_tuple':b,'same_inode':same})+'\n')
   if name!='legacy-source': direct[name+'/'+rel]=(a,src/rel)
  expected=next(t for t in manifest['trees'] if t['name']==name)
  if expected!=summary: discrepancies.append({'name':name,'expected':expected,'observed':summary})
  summaries.append(summary); hash_totals[name]=hashes.hexdigest()
 # Pin every adopted asset's hash against its real backing, including aliases.
 declared_count=0
 for asset in manifest['assets']:
  if asset['path'].startswith('audio-declared/'):
   base=W/'content/original-audio-compat' if asset['source_category']=='compat' else S
   a=file_tuple(base/asset['source_path']); b=file_tuple(A/asset['path']); declared_count+=1
   log.write(json.dumps({'tree':'audio-declared','relative':asset['path'],'source':str(base/asset['source_path']),'target':str(A/asset['path']),'source_tuple':a,'target_tuple':b,'same_inode':(a['dev'],a['ino'])==(b['dev'],b['ino'])})+'\n')
  else: a,_=direct[asset['path']]; b=a
  assert a['sha256']==asset['sha256']==b['sha256'] and a['size']==asset['size']==b['size'],asset['path']
 # Existing command can only restore these expected link counts.
 predicted=[{**s,'hardlinked':s['files'] if h else 0,'copied':0 if h else s['files']} for s,(_,_,_,h) in zip(summaries,trees)]
 assert predicted==manifest['trees'],{'predicted':predicted,'expected':manifest['trees']}
tracked_stats={t:sig(W/t) for t in tracked if (W/t).exists() or (W/t).is_symlink()}
result={'phase':phase,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'worktree':str(W),'source_root':str(S),'head':git('rev-parse','HEAD'),'staged':git('diff','--cached','--name-only'),'source31_count':len(changed),'compat_frozen_count':len(compat),'pins':pins,'observed_trees':summaries,'expected_trees':manifest['trees'],'differences':discrepancies,'ordered_relative_sha256_totals':hash_totals,'declared_count':declared_count,'mutable_roots':[str(p) for p in allowed],'tracked_stats':tracked_stats}
if phase=='after':
 before=json.loads((D/'before.json').read_text()); assert result['pins']==before['pins'],'pinned bytes changed'
 diffs=[t for t in tracked_stats if tracked_stats[t]!=before['tracked_stats'].get(t)]
 assert set(tracked_stats)==set(before['tracked_stats'])
 assert set(diffs)<= {'content/original/asset-manifest.json'},diffs
 assert not discrepancies,discrepancies
 result['tracked_stat_changes']=diffs
 assert hash_totals==before['ordered_relative_sha256_totals']
else:
 cache_path.write_text(json.dumps(cache))
(D/f'{phase}.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'pins','tracked_stats'}},indent=2))
