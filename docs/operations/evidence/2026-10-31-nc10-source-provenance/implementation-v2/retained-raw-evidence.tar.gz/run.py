from pathlib import Path
import os,sys,json,subprocess,shutil,time,datetime
ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT/'worktree'
TARGET=ROOT/'target'
assert TARGET.is_dir() and not TARGET.is_symlink() and TARGET.stat().st_uid==os.getuid()
if sys.argv[1]=='--locked':
 free=shutil.disk_usage(TARGET).free
 print(json.dumps({'freeBefore':free,'target':str(TARGET),'uid':os.getuid()}),flush=True)
 assert free>=3*1024**3,'disk below 3GiB: stop'
 env=dict(os.environ,CARGO_TARGET_DIR=str(TARGET),CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='2')
 sys.exit(subprocess.run(sys.argv[2:],cwd=WORK,env=env).returncode)
name=sys.argv[1];args=sys.argv[2:];out=ROOT/'evidence'
assert not (out/(name+'.log')).exists()
start=time.monotonic()
with (out/(name+'.log')).open('wb')as log:
 r=subprocess.run(['python3','-B','/tmp/noname-run-serialized.py','python3','-B',str(Path(__file__).resolve()),'--locked',*args],cwd=WORK,stdout=log,stderr=subprocess.STDOUT)
(out/(name+'.json')).write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args,'exit':r.returncode,'wallIncludingLockQueueSeconds':time.monotonic()-start,'log':name+'.log','diskFree':shutil.disk_usage(TARGET).free},indent=2)+'\n')
