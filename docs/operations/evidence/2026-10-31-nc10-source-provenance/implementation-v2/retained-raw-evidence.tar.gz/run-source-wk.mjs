import {createServer} from "node:http";
import {readFileSync,writeFileSync,createWriteStream} from "node:fs";
import {resolve,join,extname} from "node:path";
import {spawn} from "node:child_process";
const base=resolve("../evidence"),root=join(base,"source-ui-dist");let child,timer;
const server=createServer((req,res)=>{
 if(req.method==="POST"&&req.url==="/report"){
  let body="";req.on("data",data=>body+=data);req.on("end",()=>{const value=JSON.parse(body);writeFileSync(join(base,"actual-wk-report.json"),JSON.stringify(value,null,2));console.log(body);res.writeHead(204).end();clearTimeout(timer);setTimeout(()=>{child.kill("SIGTERM");server.close();process.exitCode=value.passed?0:1;},100);});return;
 }
 const path=new URL(req.url,"http://localhost").pathname;
 const file=path==="/actual-native-ask.hex"?join(base,"physical",path):path==="/"?join(root,"index.html"):join(root,path);
 if(!file.startsWith(root)&&path!=="/actual-native-ask.hex"){res.writeHead(403).end();return;}
 try{res.writeHead(200,{"Content-Type":({".html":"text/html",".js":"text/javascript",".wasm":"application/wasm",".css":"text/css"})[extname(file)]??"text/plain"}).end(readFileSync(file));}catch{res.writeHead(404).end();}
});
await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
const url=`http://127.0.0.1:${server.address().port}/`;
const log=createWriteStream(join(base,"actual-wk-runtime.log"));
child=spawn(join(base,"source-webview"),[url],{stdio:["ignore","pipe","pipe"]});child.stdout.pipe(log);child.stderr.pipe(log);
timer=setTimeout(()=>{console.error("Owned WKWebView timed out");child.kill("SIGTERM");server.close();process.exitCode=1;},55000);
