import Cocoa
import WebKit
final class SourceWebView: NSObject, NSApplicationDelegate {
 var window: NSWindow!
 func applicationDidFinishLaunching(_ notification: Notification) {
  let web = WKWebView(frame:NSRect(x:0,y:0,width:1200,height:900))
  window = NSWindow(contentRect:web.frame,styleMask:[.titled,.closable],backing:.buffered,defer:false)
  window.contentView=web;window.title="NC10 source27 owned WKWebView"
  window.makeKeyAndOrderFront(nil)
  web.load(URLRequest(url:URL(string:CommandLine.arguments[1])!))
 }
}
let app=NSApplication.shared
let delegate=SourceWebView()
app.delegate=delegate
app.setActivationPolicy(.accessory)
app.run()
