import {build} from "../worktree/apps/web-client/node_modules/vite/dist/node/index.js";
import {resolve,join} from "node:path";
import {writeFileSync} from "node:fs";
const root=resolve("apps/web-client"),out=resolve("../evidence/source-ui-dist");
const result=await build({root,configFile:join(root,"vite.config.ts"),build:{outDir:out,emptyOutDir:true,rollupOptions:{input:join(root,"scripts/nc10-source-ui.ts")}}});
const entry=result.output.find(file=>file.type==="chunk"&&file.isEntry).fileName;
writeFileSync(join(out,"index.html"),`<!doctype html><meta charset="utf-8"><script type="module" src="/${entry}"></script><body></body>`);
